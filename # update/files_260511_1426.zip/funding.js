/**
 * 자금 관리 (funding.js)
 * - 카드: 당해 수주 / 당해 입금 / 실제 수령 / 미수
 * - 시기별 cash flow (분기/월 토글)
 * - 과제별 입금 일정 표
 */
(function () {
  'use strict';

  // ===== 유틸 =====
  function escapeHtml(s) {
    if (s == null) return '';
    var div = document.createElement('div');
    div.textContent = s;
    return div.innerHTML;
  }
  function formatNum(n) {
    var num = Number(n);
    if (isNaN(num)) return '0';
    return num.toLocaleString('ko-KR');
  }
  function setEl(id, val) {
    var el = document.getElementById(id);
    if (el) el.textContent = val;
  }

  // normalizeStatus — 자동 전환 포함 (projects.js와 동일)
  function normalizeStatus(it) {
    var raw = (it.status || it['진행 여부'] || '').toString().trim();
    var n = raw.replace(/\s/g, '');
    var today = new Date();
    var todayStr = today.getFullYear() + '-' +
      String(today.getMonth() + 1).padStart(2, '0') + '-' +
      String(today.getDate()).padStart(2, '0');
    if (n === '수행중' || n === '수행') {
      var endDate = (it.endDate || it.end || it['종료일'] || '').toString().slice(0, 10);
      if (endDate && todayStr > endDate) return '종료';
      return '수행';
    }
    if (raw === '예정') {
      var submitDate = (it.submitDate || it['제출일'] || '').toString().slice(0, 10);
      if (submitDate && todayStr > submitDate) return '대기';
      return '예정';
    }
    if (raw === '대기' || raw === '종료' || raw === '미선정' || raw === '미제출') return raw;
    return raw || '미정';
  }

  // yearBudget의 그 해 입금분 (calendarBreakdown 우선, 없으면 일별 비례)
  function supportInYear(yb, year) {
    if (!yb) return 0;
    var cb = yb.calendarBreakdown;
    if (cb && typeof cb === 'object' && cb[year] != null && cb[year] !== '') {
      return Number(cb[year]) || 0;
    }
    var s = (yb.startDate || '').toString().slice(0, 10);
    var e = (yb.endDate   || '').toString().slice(0, 10);
    if (!s || !e) return 0;
    var support = Number(yb.support || 0);
    if (!support) return 0;
    var sd = new Date(s + 'T00:00:00');
    var ed = new Date(e + 'T00:00:00');
    if (isNaN(sd.getTime()) || isNaN(ed.getTime()) || ed < sd) return 0;
    var yearStart = new Date(year + '-01-01T00:00:00');
    var yearEnd   = new Date(year + '-12-31T00:00:00');
    var oStart = sd > yearStart ? sd : yearStart;
    var oEnd   = ed < yearEnd   ? ed : yearEnd;
    if (oStart > oEnd) return 0;
    var totalDays = ((ed - sd) / 86400000) + 1;
    var ovDays    = ((oEnd - oStart) / 86400000) + 1;
    if (sd.getFullYear() === ed.getFullYear()) {
      return Number(year) === sd.getFullYear() ? support : 0;
    }
    return Math.round(support * ovDays / totalDays);
  }

  // ===== 메인 렌더 =====

  var allProjects = [];
  var currentYear = '2026';
  var currentView = 'quarter';  // 'quarter' | 'month'

  function getYearFromDate(s) {
    return (s || '').toString().slice(0, 4);
  }
  function getMonthFromDate(s) {
    var v = (s || '').toString().slice(5, 7);
    return v ? parseInt(v, 10) : 0;
  }
  function monthToQuarter(m) {
    if (m >= 1 && m <= 3) return 1;
    if (m >= 4 && m <= 6) return 2;
    if (m >= 7 && m <= 9) return 3;
    if (m >= 10 && m <= 12) return 4;
    return 0;
  }

  function updateCards() {
    // 카드 4종: 수주 / 입금 / 실제 / 미수
    var sujuTotal = 0;
    var ipgmTotal = 0;
    var actualTotal = 0;

    allProjects.forEach(function (it) {
      var status = normalizeStatus(it);
      var isSelected = (status === '수행' || status === '종료' ||
                        status === '선정(기타)' || status === '선정 (기타)');

      if (!Array.isArray(it.yearBudgets)) return;

      it.yearBudgets.forEach(function (yb) {
        // 수주: 그 해에 시작된 연차의 support (status 조건)
        if (isSelected) {
          var ybStartYear = getYearFromDate(yb.startDate);
          if (ybStartYear === currentYear) {
            sujuTotal += Number(yb.support || 0);
          }
        }
        // 입금: 그 해 입금분 (calendarBreakdown 우선)
        ipgmTotal += supportInYear(yb, currentYear);

        // 실제 수령: payments의 실제 금액 (그 해에 수령한 것)
        if (Array.isArray(yb.payments)) {
          yb.payments.forEach(function (p) {
            var actualY = getYearFromDate(p.actualDate);
            if (actualY === currentYear && p.actualAmount) {
              actualTotal += Number(p.actualAmount) || 0;
            }
          });
        }
      });
    });

    var unpaid = ipgmTotal - actualTotal;

    setEl('funding-suju-total', formatNum(sujuTotal));
    setEl('funding-ipgm-total', formatNum(ipgmTotal));
    setEl('funding-actual-total', formatNum(actualTotal));
    setEl('funding-unpaid-total', formatNum(unpaid));
  }

  function renderPeriodBar() {
    var container = document.getElementById('funding-period-bar');
    if (!container) return;

    var bins;  // 분기 또는 월별 bin
    if (currentView === 'quarter') {
      bins = [
        { label: '1분기 (1-3월)', planned: 0, actual: 0 },
        { label: '2분기 (4-6월)', planned: 0, actual: 0 },
        { label: '3분기 (7-9월)', planned: 0, actual: 0 },
        { label: '4분기 (10-12월)', planned: 0, actual: 0 }
      ];
    } else {
      bins = [];
      for (var m = 1; m <= 12; m++) {
        bins.push({ label: m + '월', planned: 0, actual: 0 });
      }
    }

    // 모든 payment 순회
    allProjects.forEach(function (it) {
      if (!Array.isArray(it.yearBudgets)) return;
      it.yearBudgets.forEach(function (yb) {
        if (!Array.isArray(yb.payments)) return;
        yb.payments.forEach(function (p) {
          // 예정 — plannedDate가 currentYear인 경우
          var pY = getYearFromDate(p.plannedDate);
          if (pY === currentYear) {
            var pM = getMonthFromDate(p.plannedDate);
            if (pM > 0) {
              var binIdx = currentView === 'quarter' ? (monthToQuarter(pM) - 1) : (pM - 1);
              if (binIdx >= 0 && binIdx < bins.length) {
                bins[binIdx].planned += Number(p.plannedAmount || 0);
              }
            }
          }
          // 실제 — actualDate 기준
          var aY = getYearFromDate(p.actualDate);
          if (aY === currentYear && p.actualAmount) {
            var aM = getMonthFromDate(p.actualDate);
            if (aM > 0) {
              var binIdx2 = currentView === 'quarter' ? (monthToQuarter(aM) - 1) : (aM - 1);
              if (binIdx2 >= 0 && binIdx2 < bins.length) {
                bins[binIdx2].actual += Number(p.actualAmount || 0);
              }
            }
          }
        });
      });
    });

    var cls = currentView === 'quarter' ? 'period-bar--quarter' : 'period-bar--month';
    container.innerHTML = '<div class="period-bar ' + cls + '">' +
      bins.map(function (b) {
        var diff = b.planned - b.actual;
        var diffHtml = '';
        if (b.planned > 0) {
          if (diff === 0) {
            diffHtml = '<div class="period-card-diff period-card-diff--ok">✓ 일치</div>';
          } else if (diff > 0) {
            diffHtml = '<div class="period-card-diff">미수 ' + formatNum(diff) + '원</div>';
          } else {
            diffHtml = '<div class="period-card-diff period-card-diff--ok">초과 ' + formatNum(-diff) + '원</div>';
          }
        }
        var actualCls = b.actual > 0 ? '' : 'period-card-actual--zero';
        return '<div class="period-card">' +
          '<div class="period-card-label">' + b.label + '</div>' +
          '<div class="period-card-planned">예정 ' + formatNum(b.planned) + '</div>' +
          '<div class="period-card-actual ' + actualCls + '">실제 ' + formatNum(b.actual) + '</div>' +
          diffHtml +
        '</div>';
      }).join('') + '</div>';
  }

  function renderProjectTable() {
    var container = document.getElementById('funding-project-table');
    if (!container) return;

    // 그 해 입금 일정이 있는 과제만 추출
    var rows = [];
    var today = new Date();
    var todayStr = today.getFullYear() + '-' +
      String(today.getMonth() + 1).padStart(2, '0') + '-' +
      String(today.getDate()).padStart(2, '0');

    allProjects.forEach(function (it) {
      if (!Array.isArray(it.yearBudgets)) return;
      it.yearBudgets.forEach(function (yb, ybIdx) {
        if (!Array.isArray(yb.payments)) return;
        yb.payments.forEach(function (p) {
          var pY = getYearFromDate(p.plannedDate);
          var aY = getYearFromDate(p.actualDate);
          // 그 해 예정이거나 그 해 실제 수령 둘 중 하나라도 매칭되면 표시
          if (pY !== currentYear && aY !== currentYear) return;

          var status;
          if (p.actualAmount && p.actualAmount > 0) {
            status = 'paid';
          } else if (p.plannedDate && p.plannedDate < todayStr) {
            status = 'overdue';
          } else {
            status = 'unpaid';
          }

          rows.push({
            name: it.projectName || it.keywords || '(이름 없음)',
            cha: (ybIdx + 1) + '차',
            plannedDate: p.plannedDate || '',
            plannedAmount: Number(p.plannedAmount || 0),
            actualDate: p.actualDate || '',
            actualAmount: Number(p.actualAmount || 0),
            status: status,
            id: it.id
          });
        });
      });
    });

    if (!rows.length) {
      container.innerHTML = '<div class="funding-table" style="padding:0;"><div class="funding-empty">' +
        currentYear + '년 입금 일정이 없습니다.<br>' +
        '<span style="font-size:0.82rem;">과제 등록/수정 페이지에서 입금 일정을 입력하세요.</span>' +
        '</div></div>';
      return;
    }

    // 예정일 순 정렬
    rows.sort(function (a, b) {
      return (a.plannedDate || a.actualDate).localeCompare(b.plannedDate || b.actualDate);
    });

    var statusPill = {
      paid:    '<span class="f-status-pill f-status-paid">수령</span>',
      unpaid:  '<span class="f-status-pill f-status-unpaid">예정</span>',
      overdue: '<span class="f-status-pill f-status-overdue">미수</span>'
    };

    var tbody = rows.map(function (r) {
      var trCls = r.status === 'paid' ? 'f-row--paid' : (r.status === 'overdue' ? 'f-row--unpaid' : '');
      var actualText = r.actualAmount > 0 ? formatNum(r.actualAmount) : '-';
      return '<tr class="' + trCls + '">' +
        '<td>' + statusPill[r.status] + '</td>' +
        '<td>' + escapeHtml(r.plannedDate) + '</td>' +
        '<td><a href="project-detail.html?id=' + encodeURIComponent(r.id || '') + '" style="color:#1d4ed8;text-decoration:none;">' + escapeHtml(r.name) + '</a> <span style="font-size:0.78rem;color:#9ca3af;">' + r.cha + '</span></td>' +
        '<td class="f-amount">' + formatNum(r.plannedAmount) + '</td>' +
        '<td>' + escapeHtml(r.actualDate) + '</td>' +
        '<td class="f-amount">' + actualText + '</td>' +
      '</tr>';
    }).join('');

    container.innerHTML =
      '<table class="funding-table">' +
        '<thead><tr>' +
          '<th style="width:70px">상태</th>' +
          '<th style="width:120px">예정일</th>' +
          '<th>과제명</th>' +
          '<th style="width:140px;text-align:right">예정 금액</th>' +
          '<th style="width:120px">실제 수령일</th>' +
          '<th style="width:140px;text-align:right">실제 금액</th>' +
        '</tr></thead>' +
        '<tbody>' + tbody + '</tbody>' +
      '</table>';
  }

  function renderAll() {
    updateCards();
    renderPeriodBar();
    renderProjectTable();
  }

  // ===== 초기화 =====

  function init() {
    var yearFilter = document.getElementById('funding-year-filter');
    if (yearFilter) {
      currentYear = yearFilter.value;
      yearFilter.addEventListener('change', function () {
        currentYear = this.value;
        renderAll();
      });
    }

    document.querySelectorAll('.view-toggle-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        document.querySelectorAll('.view-toggle-btn').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        currentView = btn.getAttribute('data-view');
        renderPeriodBar();
      });
    });

    // Firestore 구독
    if (typeof window.firestoreService === 'object' && typeof window.firestoreService.subscribeProjects === 'function') {
      window.firestoreService.subscribeProjects(function (projects) {
        allProjects = projects || [];
        renderAll();
      });
    } else {
      // firestoreService 없는 경우 — 빈 데이터
      allProjects = [];
      renderAll();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

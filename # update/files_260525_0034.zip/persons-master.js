/**
 * 인력 마스터 (persons-master.html) 페이지 로직
 * - Firestore의 persons 컬렉션 실시간 구독
 * - 목록 렌더링 / 검색 / 상태 필터 / 청년 필터
 * - 요약 카드 (전체/활성/청년/퇴사) 자동 갱신
 *
 * 인력 항목 구조:
 *   { id, name, hireDate, exitDate, isYouth, monthlySalary, memo, status, createdAt, updatedAt }
 *
 * Step 2-1 범위: 목록 + 필터링만. 추가/수정/삭제 모달은 Step 2-2에서 추가 예정.
 */
(function () {
  'use strict';

  // ====================================================================
  // 상태
  // ====================================================================
  var _persons = [];               // Firestore에서 받아온 원본 배열
  var _filter = {
    keyword: '',                   // 이름 검색
    status: 'active',              // 'all' | 'active' | 'exited'
    youthOnly: false               // true면 isYouth=true만
  };

  // ====================================================================
  // DOM
  // ====================================================================
  var el = {
    tbody: null,
    tableWrap: null,
    empty: null,
    emptyTitle: null,
    emptyDesc: null,
    countHint: null,
    search: null,
    searchWrap: null,
    searchClear: null,
    filterStatus: null,
    filterYouth: null,
    addBtn: null,
    statTotal: null,
    statTotalSub: null,
    statActive: null,
    statYouth: null,
    statExited: null
  };

  // ====================================================================
  // 유틸
  // ====================================================================
  function $(id) { return document.getElementById(id); }

  function escapeHtml(s) {
    if (s == null) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatMoney(n) {
    if (n == null || n === '' || isNaN(Number(n))) return '-';
    var v = Math.round(Number(n));
    return v.toLocaleString('ko-KR') + '원';
  }

  function formatDate(s) {
    if (!s) return '-';
    // YYYY-MM-DD 그대로 사용 (저장 형식)
    return String(s).slice(0, 10);
  }

  // ====================================================================
  // 필터링
  // ====================================================================
  function applyFilter(list) {
    var kw = (_filter.keyword || '').trim().toLowerCase();
    return (list || []).filter(function (p) {
      if (!p) return false;

      // 상태
      if (_filter.status !== 'all') {
        var st = p.status || 'active';
        if (st !== _filter.status) return false;
      }

      // 청년 필터
      if (_filter.youthOnly && !p.isYouth) return false;

      // 이름 검색
      if (kw) {
        var name = (p.name || '').toLowerCase();
        if (name.indexOf(kw) < 0) return false;
      }

      return true;
    });
  }

  // ====================================================================
  // 요약 카드 (전체 데이터 기준 — 필터 영향 받지 않음)
  // ====================================================================
  function updateSummary() {
    var total = _persons.length;
    var active = 0, exited = 0, youth = 0;
    for (var i = 0; i < _persons.length; i++) {
      var p = _persons[i];
      if (!p) continue;
      var st = p.status || 'active';
      if (st === 'exited') exited++;
      else active++;
      if (p.isYouth && st !== 'exited') youth++;
    }
    if (el.statTotal) el.statTotal.textContent = total;
    if (el.statTotalSub) el.statTotalSub.textContent = '활성 ' + active + ' · 퇴사 ' + exited;
    if (el.statActive) el.statActive.textContent = active;
    if (el.statYouth) el.statYouth.textContent = youth;
    if (el.statExited) el.statExited.textContent = exited;
  }

  // ====================================================================
  // 렌더링
  // ====================================================================
  function renderRow(p, idx) {
    var isExited = (p.status === 'exited');
    var rowStyle = isExited ? 'style="color:#9ca3af;background:#fafafa"' : '';

    // 청년 뱃지
    var youthBadge = p.isYouth
      ? '<span class="projects-badge" style="background:#ede9fe;color:#6d28d9">청년</span>'
      : '<span style="color:#cbd5e1;font-size:0.85rem">-</span>';

    // 상태 뱃지
    var statusBadge = isExited
      ? '<span class="projects-badge projects-badge--end">퇴사</span>'
      : '<span class="projects-badge projects-badge--ongoing">활성</span>';

    // 이름 표시 (퇴사면 취소선)
    var nameHtml = isExited
      ? '<span style="text-decoration:line-through">' + escapeHtml(p.name || '-') + '</span>'
      : escapeHtml(p.name || '-');

    // 메모 (있을 때만)
    var memoHtml = p.memo
      ? '<span style="color:#64748b;font-size:0.85rem">' + escapeHtml(p.memo) + '</span>'
      : '<span style="color:#cbd5e1">-</span>';

    return ''
      + '<tr ' + rowStyle + ' data-person-id="' + escapeHtml(p.id || '') + '">'
        + '<td>' + (idx + 1) + '</td>'
        + '<td style="text-align:left;font-weight:600">' + nameHtml + '</td>'
        + '<td>' + escapeHtml(formatDate(p.hireDate)) + '</td>'
        + '<td>' + youthBadge + '</td>'
        + '<td class="col-num">' + escapeHtml(formatMoney(p.monthlySalary)) + '</td>'
        + '<td>' + statusBadge + '</td>'
        + '<td style="text-align:left">' + memoHtml + '</td>'
        + '<td>'
          + '<button type="button" class="project-edit-btn" '
          +   'data-action="edit" data-person-id="' + escapeHtml(p.id || '') + '" '
          +   'title="인력 수정 (Step 2-2 예정)" '
          +   'style="background:transparent;border:1px solid #e5e7eb;border-radius:0.35rem;padding:0.25rem 0.5rem;cursor:pointer;color:#64748b;font-size:0.8rem">'
          +   '수정'
          + '</button>'
        + '</td>'
      + '</tr>';
  }

  function render() {
    if (!el.tbody) return;

    // 요약은 전체 기준
    updateSummary();

    // 필터 적용
    var filtered = applyFilter(_persons);

    // 빈 상태 처리
    var totalCount = _persons.length;
    var filteredCount = filtered.length;

    if (totalCount === 0) {
      // 데이터 자체가 없음
      if (el.tableWrap) el.tableWrap.style.display = 'none';
      if (el.empty) el.empty.style.display = 'block';
      if (el.emptyTitle) el.emptyTitle.textContent = '아직 등록된 인력이 없어요';
      if (el.emptyDesc) {
        el.emptyDesc.innerHTML = '오른쪽 위 <strong>"+ 인력 추가"</strong> 버튼으로 첫 인력을 등록해 보세요.<br>'
          + '등록된 인력은 프로젝트별 인건비 페이지에서 검색하여 추가할 수 있어요.';
      }
      if (el.countHint) el.countHint.textContent = '0명';
      el.tbody.innerHTML = '';
      return;
    }

    if (filteredCount === 0) {
      // 데이터는 있는데 필터로 모두 걸러짐
      if (el.tableWrap) el.tableWrap.style.display = 'none';
      if (el.empty) el.empty.style.display = 'block';
      if (el.emptyTitle) el.emptyTitle.textContent = '조건에 맞는 인력이 없어요';
      if (el.emptyDesc) {
        el.emptyDesc.innerHTML = '검색어나 필터를 다시 확인해 보세요.<br>(전체 ' + totalCount + '명 등록됨)';
      }
      if (el.countHint) el.countHint.textContent = '0명 / 전체 ' + totalCount + '명';
      el.tbody.innerHTML = '';
      return;
    }

    // 정상 표시
    if (el.tableWrap) el.tableWrap.style.display = '';
    if (el.empty) el.empty.style.display = 'none';

    // 정렬: 활성 우선, 그 다음 이름순 (한국어)
    var sorted = filtered.slice().sort(function (a, b) {
      var aExit = (a.status === 'exited') ? 1 : 0;
      var bExit = (b.status === 'exited') ? 1 : 0;
      if (aExit !== bExit) return aExit - bExit;
      return (a.name || '').localeCompare(b.name || '', 'ko');
    });

    var html = '';
    for (var i = 0; i < sorted.length; i++) {
      html += renderRow(sorted[i], i);
    }
    el.tbody.innerHTML = html;

    if (el.countHint) {
      if (filteredCount === totalCount) {
        el.countHint.textContent = totalCount + '명';
      } else {
        el.countHint.textContent = filteredCount + '명 / 전체 ' + totalCount + '명';
      }
    }
  }

  // ====================================================================
  // 이벤트
  // ====================================================================
  function onSearchInput() {
    _filter.keyword = el.search.value || '';
    if (el.searchWrap) {
      if (_filter.keyword) el.searchWrap.classList.add('has-value');
      else el.searchWrap.classList.remove('has-value');
    }
    render();
  }

  function onSearchClear() {
    if (!el.search) return;
    el.search.value = '';
    onSearchInput();
    el.search.focus();
  }

  function onFilterStatusChange() {
    _filter.status = el.filterStatus.value || 'all';
    render();
  }

  function onFilterYouthChange() {
    _filter.youthOnly = !!el.filterYouth.checked;
    render();
  }

  function onAddBtnClick() {
    // Step 2-2에서 모달로 교체 예정
    alert('인력 추가 모달은 다음 단계(Step 2-2)에서 만들 예정이에요.\n조금만 기다려주세요! 😊');
  }

  function onTableClick(e) {
    var btn = e.target.closest && e.target.closest('button[data-action="edit"]');
    if (!btn) return;
    // Step 2-2에서 수정 모달로 교체 예정
    var id = btn.getAttribute('data-person-id') || '';
    var p = null;
    for (var i = 0; i < _persons.length; i++) {
      if (_persons[i] && _persons[i].id === id) { p = _persons[i]; break; }
    }
    alert('인력 수정 모달은 다음 단계(Step 2-2)에서 만들 예정이에요.\n\n선택된 인력: ' + (p ? p.name : '(알 수 없음)'));
  }

  function bindEvents() {
    if (el.search) {
      el.search.addEventListener('input', onSearchInput);
    }
    if (el.searchClear) {
      el.searchClear.addEventListener('click', onSearchClear);
    }
    if (el.filterStatus) {
      el.filterStatus.addEventListener('change', onFilterStatusChange);
    }
    if (el.filterYouth) {
      el.filterYouth.addEventListener('change', onFilterYouthChange);
    }
    if (el.addBtn) {
      el.addBtn.addEventListener('click', onAddBtnClick);
    }
    if (el.tbody) {
      el.tbody.addEventListener('click', onTableClick);
    }
  }

  // ====================================================================
  // 초기화
  // ====================================================================
  function init() {
    el.tbody         = $('persons-tbody');
    el.tableWrap     = $('persons-table-wrap');
    el.empty         = $('persons-empty');
    el.emptyTitle    = $('persons-empty-title');
    el.emptyDesc     = $('persons-empty-desc');
    el.countHint     = $('person-count-hint');
    el.search        = $('person-search');
    el.searchWrap    = $('search-wrap');
    el.searchClear   = $('search-clear');
    el.filterStatus  = $('filter-status');
    el.filterYouth   = $('filter-youth');
    el.addBtn        = $('person-add-btn');
    el.statTotal     = $('stat-total');
    el.statTotalSub  = $('stat-total-sub');
    el.statActive    = $('stat-active');
    el.statYouth     = $('stat-youth');
    el.statExited    = $('stat-exited');

    bindEvents();

    // Firestore 실시간 구독
    if (!window.firestoreService || typeof window.firestoreService.subscribePersons !== 'function') {
      console.error('firestoreService.subscribePersons 가 없습니다. firestore-service.js 가 먼저 로드되었는지 확인하세요.');
      // 빈 상태라도 표시
      render();
      return;
    }

    window.firestoreService.subscribePersons(function (list) {
      _persons = Array.isArray(list) ? list : [];
      render();
    });

    // 첫 렌더 (구독 콜백 오기 전 빈 상태)
    render();
  }

  // DOM 준비되면 실행
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

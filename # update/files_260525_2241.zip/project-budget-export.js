/* ============================================================
 * project-budget-export.js
 * ------------------------------------------------------------
 * 인건비 예산 페이지의 "참여연구원 표 내보내기" 기능.
 *
 * 두 가지 표 양식 지원:
 *   - form1 : 참여연구원 현황 (정부 R&D 표준 양식, 상세 컬럼 多)
 *   - form2 : 인건비 계상 합계 ((A/12)×B×(C/100) 자동 계산)
 *
 * 다운로드:
 *   - 📊 엑셀(.xlsx) : SheetJS(XLSX 전역)
 *   - 📄 한글(.hwpx) : JSZip으로 OWPML 패키지 생성
 *
 * 의존성 (전역):
 *   - XLSX                 (이미 페이지에 추가됨)
 *   - JSZip                (CDN으로 추가됨)
 *   - window.__pbExport    (project-budget.js가 노출하는 데이터 액세스 API)
 *     {
 *       getProject()      : { id, projectName, company, startDate, endDate, ... }
 *       getCurrentYear()  : { yearIndex, period: {startDate,endDate,months} }
 *       getRows()         : [...current year's rows]
 *       getPersonById(id) : person object (jspersons)
 *       getAllPersons()   : person[] (회사 필터 적용)
 *     }
 *
 * UI 흐름:
 *   1. 사용자가 양식 드롭다운 변경 → 미리보기 즉시 갱신
 *   2. 인력별 체크박스 토글 → 미리보기 갱신
 *   3. [📊 엑셀] / [📄 한글] 버튼 → 파일 다운로드
 *
 * 데이터 매핑 (row → 표 컬럼):
 *   row.personId        → person.name, person.birthDate, person.gender, etc.
 *   row.position        → 직위
 *   row.actualPay       → 월급 (급여총액 = actualPay × 12)
 *   row.rate            → 인건비계상률(%)
 *   row.participMonths  → 참여기간(개월)
 *   row.cashOrInkind    → 현금/현물
 *   row.newOrExisting   → 기존/신규
 *   row.role            → 담당역할
 * ============================================================ */
(function () {
  'use strict';

  // localStorage 키
  var LS_SELECTED_KEY = 'rnd-pb-export-selected'; // { [projectId+yearIndex]: [personId,...] } - 체크된 인력
  var LS_FORM_KEY     = 'rnd-pb-export-form';     // 'form1' | 'form2'
  var LS_PERIOD_KEY   = 'rnd-pb-export-period';   // { [rowId]: 'YYYY-MM ~ YYYY-MM' } - 인력별 참여기간 오버라이드
  var LS_ROLE_KEY     = 'rnd-pb-export-role';     // { [rowId]: '담당역할' } - 인력별 담당역할 (row.role과 별도 - export 전용)

  // 상태
  var _state = {
    form: 'form1',                // 현재 선택 양식
    selectedRowIds: null,         // Set<rowId> | null (null=전체)
    periodOverride: {},           // { [rowId]: 'YYYY.MM ~ YYYY.MM' }
    roleOverride: {},             // { [rowId]: '담당역할' }
  };

  // ========================================================================
  // 유틸
  // ========================================================================
  function $(id) { return document.getElementById(id); }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function escapeXml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  }

  function fmtMoney(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('ko-KR');
  }

  function fmtDateCompact(iso) {
    // 'YYYY-MM-DD' → 'YYYY.MM.DD'
    if (!iso) return '';
    return String(iso).replace(/-/g, '.');
  }

  function fmtPeriodYM(startIso, endIso) {
    // 'YYYY-MM-DD', 'YYYY-MM-DD' → 'YYYY.MM ~ YYYY.MM'
    if (!startIso || !endIso) return '';
    var s = String(startIso).slice(0, 7).replace('-', '.');
    var e = String(endIso).slice(0, 7).replace('-', '.');
    return s + ' ~ ' + e;
  }

  function ymdToDateParts(iso) {
    if (!iso) return { y: '', m: '', d: '' };
    var p = String(iso).split('-');
    return { y: p[0] || '', m: p[1] || '', d: p[2] || '' };
  }

  function genderLabel(g) {
    if (g === 'M' || g === '남') return '남';
    if (g === 'F' || g === '여') return '여';
    return '';
  }

  function downloadBlob(blob, filename) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function toast(msg, isError) {
    var el = $('pb-toast');
    if (!el) return;
    el.textContent = msg;
    el.style.background = isError ? '#dc2626' : '#059669';
    el.style.opacity = '1';
    el.style.transform = 'translateX(-50%) translateY(0)';
    clearTimeout(toast._t);
    toast._t = setTimeout(function () {
      el.style.opacity = '0';
      el.style.transform = 'translateX(-50%) translateY(8px)';
    }, 2200);
  }

  // ========================================================================
  // localStorage I/O
  // ========================================================================
  function getStorageKey(projectId, yearIndex) {
    return (projectId || '') + '#' + (yearIndex || 1);
  }

  function loadSelectedRows(projectId, yearIndex) {
    try {
      var raw = localStorage.getItem(LS_SELECTED_KEY);
      if (!raw) return null;
      var data = JSON.parse(raw);
      var k = getStorageKey(projectId, yearIndex);
      var arr = data[k];
      return Array.isArray(arr) ? arr : null;
    } catch (e) { return null; }
  }

  function saveSelectedRows(projectId, yearIndex, rowIds) {
    try {
      var raw = localStorage.getItem(LS_SELECTED_KEY);
      var data = raw ? JSON.parse(raw) : {};
      var k = getStorageKey(projectId, yearIndex);
      data[k] = Array.from(rowIds);
      localStorage.setItem(LS_SELECTED_KEY, JSON.stringify(data));
    } catch (e) {}
  }

  function loadForm() {
    try {
      var v = localStorage.getItem(LS_FORM_KEY);
      return (v === 'form2') ? 'form2' : 'form1';
    } catch (e) { return 'form1'; }
  }

  function saveForm(v) {
    try { localStorage.setItem(LS_FORM_KEY, v); } catch (e) {}
  }

  function loadOverrides(key) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : {};
    } catch (e) { return {}; }
  }

  function saveOverrides(key, obj) {
    try { localStorage.setItem(key, JSON.stringify(obj)); } catch (e) {}
  }

  // ========================================================================
  // 행 → 표 데이터 변환
  // ========================================================================
  /**
   * 현재 연차의 row들을 표 양식에 맞게 가공.
   * @returns {Array} 각 항목 = { rowId, personId, included, mapped: {...} }
   */
  function buildRowDataset() {
    var api = window.__pbExport;
    if (!api) return [];
    var project = api.getProject();
    if (!project) return [];
    var year = api.getCurrentYear();
    var rows = api.getRows() || [];

    var defaultPeriod = '';
    if (project.startDate && project.endDate) {
      defaultPeriod = fmtPeriodYM(project.startDate, project.endDate);
    } else if (year && year.period) {
      defaultPeriod = fmtPeriodYM(year.period.startDate, year.period.endDate);
    }

    var selectedIds = _state.selectedRowIds; // Set | null

    return rows.map(function (row, idx) {
      var person = row.personId ? api.getPersonById(row.personId) : null;
      var included = selectedIds ? selectedIds.has(row.id) : true;

      var monthly  = Number(row.actualPay) || Number(row.monthlySalary) || (person && person.monthlySalary) || 0;
      var annual   = monthly * 12; // 급여총액(A)
      var rate     = Number(row.rate) || 0;
      var months   = Number(row.participMonths) || 0;
      // 합계 = (A/12) × B × (C/100) = monthly × months × rate/100
      var total    = Math.round(monthly * months * rate / 100);

      // 참여기간: 인력별 오버라이드 → 프로젝트 기본
      var period = _state.periodOverride[row.id] || defaultPeriod;
      // 담당역할: row.role > export 오버라이드
      var role = (row.role && row.role.trim()) || _state.roleOverride[row.id] || '';

      // 청년/신규 컬럼 라벨
      var newOrExist = row.newOrExisting || (person && person.isNew ? '신규' : '기존');
      var youthLabel = '';
      if (person && person.isYouth) {
        youthLabel = (newOrExist === '신규') ? '신규(청년)' : '청년';
      } else {
        youthLabel = newOrExist === '신규' ? '신규' : '기존';
      }

      // 학위
      var degree = (person && person.finalDegree) || '';
      var major  = (person && person.major) || '';
      var degYr  = '';
      if (person && person.degreeDate) {
        degYr = String(person.degreeDate).slice(0, 4);
      }

      // 생년월일 / 성별 → "YYYY.MM.DD(남/여)" 표기
      var birth = (person && person.birthDate) || '';
      var gender = person ? genderLabel(person.gender) : '';
      var birthGender = birth
        ? (fmtDateCompact(birth) + (gender ? '(' + gender + ')' : ''))
        : (gender ? '(' + gender + ')' : '');

      // 성명(국적) → 일단 국적 데이터가 없으므로 (한국)
      var nameNat = (row.personName || (person && person.name) || '') + '(한국)';

      // 소속기관(역할): 회사 + role 으로 구성. 단, 표1은 [소속기관(역할)] 한 컬럼.
      var company = (person && person.company) || project.company || '';
      var orgRole = company + (role ? '(' + role + ')' : '');

      // 직위
      var position = row.position || (person && person.position) || '';

      // 인력 구분(표2): "내부 / 기존(청년)" 식
      var personType  = '내부'; // 외부 데이터가 없으면 기본 내부
      var newDetail   = youthLabel; // '기존' | '신규' | '청년' | '신규(청년)'

      return {
        rowId: row.id,
        personId: row.personId || '',
        rowType: row.type || 'normal', // normal | youth_required | youth_additional
        included: included,
        mapped: {
          // 공통
          name:        row.personName || (person && person.name) || '',
          nameNat:     nameNat,
          orgRole:     orgRole,        // 소속기관(역할)
          newOrExist:  youthLabel,     // 기존/신규(청년/일반)/시간선택/외부
          position:    position,
          birthGender: birthGender,
          // 학위
          degree:      degree,
          major:       major,
          degreeYear:  degYr,
          // 역할/기간
          role:        role,
          period:      period,
          // 인건비계상률
          rateA:       rate,           // 본 연구개발사업
          rateB:       0,              // 타 사업 (현재 데이터 없음)
          rateAB:      rate,
          projectCnt:  '',             // 국가연구개발사업 수
          // 표2 추가 컬럼
          personType:  personType,     // 인력 구분
          inOut:       '내부',         // 내외부 및 지원구분
          annualSalary: annual,        // 급여총액(A)
          months:      months,         // 참여기간(B, 개월)
          rateC:       rate,           // 해당 차수 인건비계상률(C)
          totalCash:   row.cashOrInkind === '현금' ? total : 0,
          totalInkind: row.cashOrInkind === '현물' ? total : 0,
          totalSum:    total,
        },
      };
    });
  }

  /**
   * 표1 (참여연구원 현황) 헤더 정의.
   * 정부 R&D 양식 - 첫 캡처 기준.
   */
  function getForm1HeaderRows() {
    // 2단 헤더. SheetJS도 헤더만 일반 셀로 처리 (병합은 옵션).
    return {
      // 사람이 읽는 헤더
      headers: [
        '번호',
        '소속기관(역할)',
        '기존/신규(청년,일반)·시간선택/외부',
        '성명(국적)',
        '직위',
        '생년월일(성별)',
        '최종학위',
        '전공',
        '취득연도',
        '담당역할',
        '참여기간(년/월)',
        '본 연구개발사업 인건비계상률(%)',
        '타 국가연구개발사업 인건비계상률(%)',
        '전체 인건비계상률 합계(%) (A+B)',
        '국가연구개발사업 수(건) (3차/5공)',
      ],
      // mapped 객체의 키
      keys: [
        '_no', 'orgRole', 'newOrExist', 'nameNat', 'position',
        'birthGender', 'degree', 'major', 'degreeYear', 'role',
        'period', 'rateA', 'rateB', 'rateAB', 'projectCnt',
      ],
    };
  }

  /**
   * 표2 (인건비 계상 합계) 헤더 정의.
   * 두 번째 캡처: 인력구분 / 성명(국적) / 직위 / 내외부 / 기존·신규 / 급여총액(A)
   *               / 참여기간(B,개월) / 인건비계상률(C) / 합계(현금/현물/계)
   */
  function getForm2HeaderRows() {
    return {
      headers: [
        '인력구분',
        '성명(국적)',
        '직위',
        '내·외부 및 지원구분',
        '기존/신규(청년,일반)·시간선택/외부',
        '급여총액(A)',
        '참여기간 (B, 개월)',
        '해당 차수 인건비계상률(%) (C)',
        '합계 현금 ((A/12)×B×(C/100))',
        '합계 현물',
        '합계 계',
      ],
      keys: [
        'personType', 'nameNat', 'position', 'inOut', 'newOrExist',
        'annualSalary', 'months', 'rateC',
        'totalCash', 'totalInkind', 'totalSum',
      ],
    };
  }

  /**
   * 포함된(included=true) 행만 가지고, 양식에 맞춰 2D 배열 형태로 변환.
   * 표 미리보기 + 엑셀 + HWPX 가 같은 데이터를 공유.
   * @returns {{ headers: string[], rows: any[][], money: Set<number> }}
   */
  function buildTableMatrix() {
    var dataset = buildRowDataset().filter(function (d) { return d.included; });
    var spec = (_state.form === 'form2') ? getForm2HeaderRows() : getForm1HeaderRows();

    var rows = dataset.map(function (d, i) {
      var row = [];
      spec.keys.forEach(function (k) {
        if (k === '_no') {
          row.push(String(i + 1));
        } else {
          row.push(d.mapped[k] == null ? '' : d.mapped[k]);
        }
      });
      return row;
    });

    // 표2 합계 행 추가
    if (_state.form === 'form2' && rows.length > 0) {
      var sumAnnual = 0, sumMonths = 0, sumCash = 0, sumInkind = 0, sumTotal = 0;
      dataset.forEach(function (d) {
        sumAnnual += Number(d.mapped.annualSalary) || 0;
        sumMonths += Number(d.mapped.months) || 0;
        sumCash += Number(d.mapped.totalCash) || 0;
        sumInkind += Number(d.mapped.totalInkind) || 0;
        sumTotal += Number(d.mapped.totalSum) || 0;
      });
      rows.push([
        '합계', '', '', '', '',
        sumAnnual, sumMonths, '',
        sumCash, sumInkind, sumTotal,
      ]);
    }

    // 금액 컬럼 인덱스 (스타일링용)
    var moneyColIdx = new Set();
    if (_state.form === 'form2') {
      // 급여총액(5), 합계 현금(8), 현물(9), 계(10)
      [5, 8, 9, 10].forEach(function (i) { moneyColIdx.add(i); });
    }

    return { headers: spec.headers, rows: rows, money: moneyColIdx };
  }

  // ========================================================================
  // 미리보기 렌더링
  // ========================================================================
  function renderPreview() {
    var wrap = $('pb-export-preview');
    if (!wrap) return;

    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();

    if (!project || !year) {
      wrap.innerHTML = '<div class="pb-export-empty">과제와 연차를 먼저 선택해 주세요.</div>';
      return;
    }

    // 인력 체크리스트
    renderRowCheckList();

    var m = buildTableMatrix();
    if (m.rows.length === 0) {
      wrap.innerHTML = '<div class="pb-export-empty">표시할 인력이 없습니다. (체크박스로 인력을 선택해 주세요)</div>';
      return;
    }

    var html = '';
    html += '<div class="pb-export-table-title">' + escapeHtml(getTableTitle()) + '</div>';
    html += '<table class="pb-export-table"><thead><tr>';
    m.headers.forEach(function (h) {
      html += '<th>' + escapeHtml(h) + '</th>';
    });
    html += '</tr></thead><tbody>';
    m.rows.forEach(function (r, ri) {
      var isSum = (_state.form === 'form2') && (ri === m.rows.length - 1);
      html += isSum ? '<tr class="pb-export-row--sum">' : '<tr>';
      r.forEach(function (cell, ci) {
        var v = cell;
        if (m.money.has(ci) && typeof v === 'number') {
          v = fmtMoney(v);
        }
        html += '<td>' + escapeHtml(v) + '</td>';
      });
      html += '</tr>';
    });
    html += '</tbody></table>';
    wrap.innerHTML = html;
  }

  function getTableTitle() {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    var formName = (_state.form === 'form2') ? '인건비 계상 합계' : '참여연구원 현황';
    var projName = project ? (project.projectName || '') : '';
    var yi = year ? year.yearIndex : 1;
    return '[' + projName + '] ' + yi + '차년도 ' + formName;
  }

  function renderRowCheckList() {
    var list = $('pb-export-row-list');
    if (!list) return;
    var api = window.__pbExport;
    var rows = api ? api.getRows() : [];

    if (!rows.length) {
      list.innerHTML = '<div class="pb-export-empty">예산 표에 행이 없습니다.</div>';
      return;
    }

    var selected = _state.selectedRowIds;
    var html = rows.map(function (row) {
      var person = row.personId ? api.getPersonById(row.personId) : null;
      var name = row.personName || (person && person.name) || '<이름 미입력>';
      var checked = selected ? selected.has(row.id) : true;
      var typeBadge = '';
      if (row.type === 'youth_required') typeBadge = '<span class="pb-export-badge pb-export-badge--req">청년필수</span>';
      else if (row.type === 'youth_additional') typeBadge = '<span class="pb-export-badge pb-export-badge--add">청년추가</span>';
      var months = Number(row.participMonths) || 0;
      var rate = Number(row.rate) || 0;
      var sub = months + '개월 · ' + rate + '%';
      return '' +
        '<label class="pb-export-row-item">' +
          '<input type="checkbox" class="pb-export-row-cb" data-row-id="' + escapeHtml(row.id) + '"' + (checked ? ' checked' : '') + '>' +
          '<span class="pb-export-row-name">' + escapeHtml(name) + '</span>' +
          typeBadge +
          '<span class="pb-export-row-sub">' + escapeHtml(sub) + '</span>' +
        '</label>';
    }).join('');

    list.innerHTML = html;

    // 체크박스 이벤트
    list.querySelectorAll('.pb-export-row-cb').forEach(function (cb) {
      cb.addEventListener('change', function () {
        var rid = cb.dataset.rowId;
        if (!_state.selectedRowIds) {
          // 처음 토글하면 현재 전체 체크 상태에서 시작
          _state.selectedRowIds = new Set(rows.map(function (r) { return r.id; }));
        }
        if (cb.checked) {
          _state.selectedRowIds.add(rid);
        } else {
          _state.selectedRowIds.delete(rid);
        }
        persistSelection();
        renderPreview();
      });
    });
  }

  function persistSelection() {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    if (!project || !year) return;
    if (_state.selectedRowIds) {
      saveSelectedRows(project.id, year.yearIndex, _state.selectedRowIds);
    }
  }

  function restoreSelection() {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    var rows = api ? api.getRows() : [];
    if (!project || !year) {
      _state.selectedRowIds = null;
      return;
    }
    var saved = loadSelectedRows(project.id, year.yearIndex);
    if (saved && rows.length > 0) {
      // 현재 존재하는 row id만 필터
      var validIds = new Set(rows.map(function (r) { return r.id; }));
      _state.selectedRowIds = new Set(saved.filter(function (rid) { return validIds.has(rid); }));
    } else {
      _state.selectedRowIds = null; // 전체 선택
    }
  }

  // 외부에서 호출: 데이터 갱신 시 미리보기 새로 그리기
  function refresh() {
    restoreSelection();
    renderPreview();
  }

  // ========================================================================
  // 엑셀 다운로드
  // ========================================================================
  function downloadExcel() {
    if (typeof XLSX === 'undefined') {
      toast('엑셀 라이브러리를 로드하지 못했습니다.', true);
      return;
    }
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    if (!project || !year) {
      toast('과제와 연차를 먼저 선택해 주세요.', true);
      return;
    }

    var m = buildTableMatrix();
    if (m.rows.length === 0) {
      toast('내보낼 데이터가 없습니다.', true);
      return;
    }

    // 시트 데이터: 제목 + 빈줄 + 헤더 + 데이터
    var aoa = [];
    aoa.push([getTableTitle()]);
    aoa.push([]);
    aoa.push(m.headers);
    m.rows.forEach(function (r) {
      aoa.push(r.slice());
    });

    var ws = XLSX.utils.aoa_to_sheet(aoa);

    // 열 너비 (대략)
    var colCount = m.headers.length;
    var colWidths = [];
    for (var c = 0; c < colCount; c++) {
      var h = m.headers[c] || '';
      var width = Math.min(Math.max(h.length * 2.2 + 4, 10), 24);
      colWidths.push({ wch: width });
    }
    ws['!cols'] = colWidths;

    // 제목 행 병합 (A1:끝열1)
    ws['!merges'] = ws['!merges'] || [];
    ws['!merges'].push({
      s: { r: 0, c: 0 },
      e: { r: 0, c: colCount - 1 },
    });

    // 숫자 셀 포맷 (money 컬럼)
    m.rows.forEach(function (r, ri) {
      r.forEach(function (cell, ci) {
        if (m.money.has(ci) && typeof cell === 'number') {
          var addr = XLSX.utils.encode_cell({ r: ri + 3, c: ci }); // +3: 제목+빈+헤더
          if (ws[addr]) {
            ws[addr].t = 'n';
            ws[addr].z = '#,##0';
          }
        }
      });
    });

    var wb = XLSX.utils.book_new();
    var sheetName = (_state.form === 'form2') ? '인건비계상합계' : '참여연구원현황';
    XLSX.utils.book_append_sheet(wb, ws, sheetName);

    var fname = makeFilename('xlsx');
    XLSX.writeFile(wb, fname);
    toast('엑셀 다운로드 완료');
  }

  function makeFilename(ext) {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    var projName = project ? (project.projectName || 'project') : 'project';
    var yi = year ? year.yearIndex : 1;
    var formName = (_state.form === 'form2') ? '인건비계상합계' : '참여연구원현황';
    // 파일명 안전화
    var safe = projName.replace(/[\\/:*?"<>|]/g, '_');
    var today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    return safe + '_' + yi + '차년도_' + formName + '_' + today + '.' + ext;
  }


  // ========================================================================
  // HTML 표 빌더 (클립보드 + HTML 다운로드 공용)
  // ========================================================================
  /**
   * 양식에 맞는 풀 HTML 표를 만든다.
   * 클립보드 복사 시: text/html MIME 으로 넣으면 한글이 표로 인식하여 붙여넣음.
   * HTML 파일 다운로드 시: 단독 .html 파일을 열어 표 영역 복사 후 한글 붙여넣기 가능.
   *
   * 한글이 인식하는 핵심 속성:
   *   - <table border="1" style="border-collapse:collapse">
   *   - 각 td/th 에 inline style (background, font-weight)
   *   - 셀 너비는 <colgroup><col width="..."> 또는 td style="width:Xpx"
   *
   * @param {object} opts - { standalone: bool } (true면 <html><body> 감쌈)
   * @returns {string} HTML 문자열
   */
  function buildTableHtml(opts) {
    opts = opts || {};
    var m = buildTableMatrix();
    var title = getTableTitle();

    // 셀 공통 스타일 - 한글이 잘 인식하는 inline style
    var thStyle = 'border:1px solid #000;padding:6px 8px;background:#E5E7EB;font-weight:bold;text-align:center;font-size:10pt;font-family:\'함초롬바탕\',\'맑은 고딕\',sans-serif;';
    var tdStyle = 'border:1px solid #000;padding:6px 8px;text-align:center;font-size:10pt;font-family:\'함초롬바탕\',\'맑은 고딕\',sans-serif;';
    var tdSumStyle = tdStyle + 'background:#FEF3C7;font-weight:bold;';

    var html = '';

    // 제목 (한글에서 표 위 줄로 들어감)
    html += '<p style="font-size:11pt;font-weight:bold;text-align:center;margin:0 0 8px 0;font-family:\'함초롬바탕\',\'맑은 고딕\',sans-serif;">' +
            escapeHtml(title) + '</p>';

    // 표
    html += '<table border="1" cellspacing="0" cellpadding="0" ' +
            'style="border-collapse:collapse;border:1px solid #000;width:100%;table-layout:auto;">';

    // 헤더 행
    html += '<thead><tr>';
    m.headers.forEach(function (h) {
      html += '<th style="' + thStyle + '">' + escapeHtml(h) + '</th>';
    });
    html += '</tr></thead>';

    // 데이터 행
    html += '<tbody>';
    m.rows.forEach(function (r, ri) {
      var isSum = (_state.form === 'form2') && (ri === m.rows.length - 1);
      var style = isSum ? tdSumStyle : tdStyle;
      html += '<tr>';
      r.forEach(function (cell, ci) {
        var v = cell;
        if (m.money.has(ci) && typeof v === 'number') {
          v = fmtMoney(v);
        }
        // 첫 컬럼(번호/인력구분) + 합계 행은 가운데, 금액은 오른쪽
        var alignStyle = style;
        if (m.money.has(ci)) {
          alignStyle = style.replace('text-align:center', 'text-align:right');
        }
        html += '<td style="' + alignStyle + '">' + escapeHtml(v) + '</td>';
      });
      html += '</tr>';
    });
    html += '</tbody></table>';

    if (opts.standalone) {
      // 다운로드용 풀 문서
      return '<!DOCTYPE html>\n' +
        '<html lang="ko">\n<head>\n' +
        '  <meta charset="UTF-8">\n' +
        '  <title>' + escapeHtml(title) + '</title>\n' +
        '  <style>\n' +
        '    body { font-family: "함초롬바탕", "맑은 고딕", sans-serif; padding: 24px; margin: 0; background: #fff; }\n' +
        '    .pb-export-help { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 12px 16px; margin-bottom: 24px; font-size: 13px; color: #78350f; line-height: 1.6; }\n' +
        '    .pb-export-help strong { color: #451a03; }\n' +
        '    @media print { .pb-export-help { display: none; } }\n' +
        '  </style>\n' +
        '</head>\n<body>\n' +
        '  <div class="pb-export-help">\n' +
        '    <strong>📋 사용법:</strong> 아래 표 전체를 마우스로 선택(또는 Ctrl+A) → 복사(Ctrl+C) → 한글에서 붙여넣기(Ctrl+V).<br>\n' +
        '    한글에서 표 그대로 들어가며, 셀 너비·폰트는 한글에서 조정하면 됩니다.\n' +
        '  </div>\n' +
        html + '\n' +
        '</body>\n</html>';
    }

    return html;
  }

  /**
   * 한글에 붙여넣기 위해 클립보드에 HTML + 평문 둘 다 넣는다.
   * 두 가지 방식 시도:
   *   1. navigator.clipboard.write(ClipboardItem) - 모던 브라우저 (Chrome 76+, 권장)
   *   2. document.execCommand('copy') - fallback
   */
  function copyForHwp() {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    if (!project || !year) {
      toast('과제와 연차를 먼저 선택해 주세요.', true);
      return;
    }

    var m = buildTableMatrix();
    if (m.rows.length === 0) {
      toast('내보낼 데이터가 없습니다.', true);
      return;
    }

    var html = buildTableHtml({ standalone: false });
    var plain = buildPlainText(m); // 탭 구분 (한글이 텍스트만 인식할 때 fallback)

    // 1. 모던 Clipboard API 시도
    if (navigator.clipboard && window.ClipboardItem) {
      try {
        var item = new ClipboardItem({
          'text/html': new Blob([html], { type: 'text/html' }),
          'text/plain': new Blob([plain], { type: 'text/plain' }),
        });
        navigator.clipboard.write([item]).then(function () {
          toast('표 복사 완료! 한글에서 Ctrl+V로 붙여넣으세요.');
        }).catch(function (err) {
          console.warn('[Clipboard API] failed, falling back:', err);
          copyForHwpFallback(html, plain);
        });
        return;
      } catch (err) {
        console.warn('[ClipboardItem] not supported, falling back:', err);
      }
    }

    // 2. Fallback - execCommand
    copyForHwpFallback(html, plain);
  }

  /**
   * 클립보드 fallback: 임시 contenteditable div + execCommand('copy')
   * HTML 형식으로 복사됨 (한글이 표로 인식)
   */
  function copyForHwpFallback(html, plain) {
    var div = document.createElement('div');
    div.contentEditable = 'true';
    div.innerHTML = html;
    // 화면 밖에 배치
    div.style.position = 'fixed';
    div.style.left = '-9999px';
    div.style.top = '0';
    div.style.opacity = '0';
    document.body.appendChild(div);

    try {
      // 선택
      var range = document.createRange();
      range.selectNodeContents(div);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);

      var ok = document.execCommand('copy');
      sel.removeAllRanges();
      if (ok) {
        toast('표 복사 완료! 한글에서 Ctrl+V로 붙여넣으세요.');
      } else {
        toast('복사 실패. 브라우저 권한을 확인하세요.', true);
      }
    } catch (err) {
      console.error('[copy fallback] error', err);
      toast('복사 실패: ' + (err.message || err), true);
    } finally {
      document.body.removeChild(div);
    }
  }

  /**
   * 평문(탭 구분) 표 생성 - 클립보드 fallback용
   */
  function buildPlainText(m) {
    var lines = [];
    lines.push(getTableTitle());
    lines.push('');
    lines.push(m.headers.join('\t'));
    m.rows.forEach(function (r) {
      lines.push(r.map(function (cell, ci) {
        if (m.money.has(ci) && typeof cell === 'number') return fmtMoney(cell);
        return String(cell == null ? '' : cell);
      }).join('\t'));
    });
    return lines.join('\n');
  }

  /**
   * HTML 파일 다운로드 - 클립보드가 실패하거나 브라우저 호환 문제 있을 때 fallback.
   * 다운로드된 .html 파일을 열면 표가 보이고, 사용법 안내도 표시된다.
   */
  function downloadHtml() {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    if (!project || !year) {
      toast('과제와 연차를 먼저 선택해 주세요.', true);
      return;
    }

    var m = buildTableMatrix();
    if (m.rows.length === 0) {
      toast('내보낼 데이터가 없습니다.', true);
      return;
    }

    var html = buildTableHtml({ standalone: true });
    // BOM + UTF-8 (한글이 인코딩 자동 인식하도록)
    var blob = new Blob(['\uFEFF', html], { type: 'text/html;charset=utf-8' });
    var fname = makeFilename('html');
    downloadBlob(blob, fname);
    toast('HTML 파일 다운로드 완료');
  }


  // ========================================================================
  // 이벤트 바인딩
  // ========================================================================
  function bindEvents() {
    // 양식 드롭다운
    var formSel = $('pb-export-form-select');
    if (formSel) {
      formSel.value = _state.form;
      formSel.addEventListener('change', function () {
        _state.form = formSel.value;
        saveForm(_state.form);
        renderPreview();
      });
    }

    // 다운로드 버튼
    var xlsxBtn = $('pb-export-xlsx-btn');
    if (xlsxBtn) xlsxBtn.addEventListener('click', downloadExcel);

    var hwpBtn = $('pb-export-hwp-copy-btn');
    if (hwpBtn) hwpBtn.addEventListener('click', copyForHwp);

    var htmlBtn = $('pb-export-html-btn');
    if (htmlBtn) htmlBtn.addEventListener('click', downloadHtml);

    // 전체 선택 / 해제
    var selAllBtn = $('pb-export-select-all');
    var unselAllBtn = $('pb-export-unselect-all');
    if (selAllBtn) {
      selAllBtn.addEventListener('click', function () {
        var api = window.__pbExport;
        var rows = api ? api.getRows() : [];
        _state.selectedRowIds = new Set(rows.map(function (r) { return r.id; }));
        persistSelection();
        renderPreview();
      });
    }
    if (unselAllBtn) {
      unselAllBtn.addEventListener('click', function () {
        _state.selectedRowIds = new Set();
        persistSelection();
        renderPreview();
      });
    }
  }

  // ========================================================================
  // 초기화 - project-budget.js가 준비된 후 호출됨
  // ========================================================================
  function init() {
    _state.form = loadForm();
    _state.periodOverride = loadOverrides(LS_PERIOD_KEY);
    _state.roleOverride = loadOverrides(LS_ROLE_KEY);

    bindEvents();
    refresh();

    // project-budget.js가 데이터 갱신 시 호출하도록 노출
    window.__pbExportRefresh = refresh;
  }

  // project-budget.js가 노출하는 API가 준비될 때까지 기다림
  function waitForApi() {
    if (window.__pbExport) {
      init();
    } else {
      setTimeout(waitForApi, 50);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', waitForApi);
  } else {
    waitForApi();
  }

})();

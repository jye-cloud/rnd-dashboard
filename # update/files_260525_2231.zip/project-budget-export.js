/* ============================================================
 * project-budget-export.js
 * ------------------------------------------------------------
 * 인건비 예산 페이지의 "참여연구원 표 내보내기" 기능.
 *
 * 두 가지 표 양식 지원:
 *   - form1 : 참여연구원 현황 (정부 R&D 표준 양식, 상세 컬럼 多)
 *   - form2 : 인건비 계상 합계 ((A/12)×B×(C/100) 자동 계산)
 *
 * 다운로드:
 *   - 📊 엑셀(.xlsx) : SheetJS(XLSX 전역)
 *   - 📄 한글(.hwpx) : JSZip으로 OWPML 패키지 생성
 *
 * 의존성 (전역):
 *   - XLSX                 (이미 페이지에 추가됨)
 *   - JSZip                (CDN으로 추가됨)
 *   - window.__pbExport    (project-budget.js가 노출하는 데이터 액세스 API)
 *     {
 *       getProject()      : { id, projectName, company, startDate, endDate, ... }
 *       getCurrentYear()  : { yearIndex, period: {startDate,endDate,months} }
 *       getRows()         : [...current year's rows]
 *       getPersonById(id) : person object (jspersons)
 *       getAllPersons()   : person[] (회사 필터 적용)
 *     }
 *
 * UI 흐름:
 *   1. 사용자가 양식 드롭다운 변경 → 미리보기 즉시 갱신
 *   2. 인력별 체크박스 토글 → 미리보기 갱신
 *   3. [📊 엑셀] / [📄 한글] 버튼 → 파일 다운로드
 *
 * 데이터 매핑 (row → 표 컬럼):
 *   row.personId        → person.name, person.birthDate, person.gender, etc.
 *   row.position        → 직위
 *   row.actualPay       → 월급 (급여총액 = actualPay × 12)
 *   row.rate            → 인건비계상률(%)
 *   row.participMonths  → 참여기간(개월)
 *   row.cashOrInkind    → 현금/현물
 *   row.newOrExisting   → 기존/신규
 *   row.role            → 담당역할
 * ============================================================ */
(function () {
  'use strict';

  // localStorage 키
  var LS_SELECTED_KEY = 'rnd-pb-export-selected'; // { [projectId+yearIndex]: [personId,...] } - 체크된 인력
  var LS_FORM_KEY     = 'rnd-pb-export-form';     // 'form1' | 'form2'
  var LS_PERIOD_KEY   = 'rnd-pb-export-period';   // { [rowId]: 'YYYY-MM ~ YYYY-MM' } - 인력별 참여기간 오버라이드
  var LS_ROLE_KEY     = 'rnd-pb-export-role';     // { [rowId]: '담당역할' } - 인력별 담당역할 (row.role과 별도 - export 전용)

  // 상태
  var _state = {
    form: 'form1',                // 현재 선택 양식
    selectedRowIds: null,         // Set<rowId> | null (null=전체)
    periodOverride: {},           // { [rowId]: 'YYYY.MM ~ YYYY.MM' }
    roleOverride: {},             // { [rowId]: '담당역할' }
  };

  // ========================================================================
  // 유틸
  // ========================================================================
  function $(id) { return document.getElementById(id); }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function escapeXml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  }

  function fmtMoney(n) {
    var v = Number(n) || 0;
    return v.toLocaleString('ko-KR');
  }

  function fmtDateCompact(iso) {
    // 'YYYY-MM-DD' → 'YYYY.MM.DD'
    if (!iso) return '';
    return String(iso).replace(/-/g, '.');
  }

  function fmtPeriodYM(startIso, endIso) {
    // 'YYYY-MM-DD', 'YYYY-MM-DD' → 'YYYY.MM ~ YYYY.MM'
    if (!startIso || !endIso) return '';
    var s = String(startIso).slice(0, 7).replace('-', '.');
    var e = String(endIso).slice(0, 7).replace('-', '.');
    return s + ' ~ ' + e;
  }

  function ymdToDateParts(iso) {
    if (!iso) return { y: '', m: '', d: '' };
    var p = String(iso).split('-');
    return { y: p[0] || '', m: p[1] || '', d: p[2] || '' };
  }

  function genderLabel(g) {
    if (g === 'M' || g === '남') return '남';
    if (g === 'F' || g === '여') return '여';
    return '';
  }

  function downloadBlob(blob, filename) {
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  function toast(msg, isError) {
    var el = $('pb-toast');
    if (!el) return;
    el.textContent = msg;
    el.style.background = isError ? '#dc2626' : '#059669';
    el.style.opacity = '1';
    el.style.transform = 'translateX(-50%) translateY(0)';
    clearTimeout(toast._t);
    toast._t = setTimeout(function () {
      el.style.opacity = '0';
      el.style.transform = 'translateX(-50%) translateY(8px)';
    }, 2200);
  }

  // ========================================================================
  // localStorage I/O
  // ========================================================================
  function getStorageKey(projectId, yearIndex) {
    return (projectId || '') + '#' + (yearIndex || 1);
  }

  function loadSelectedRows(projectId, yearIndex) {
    try {
      var raw = localStorage.getItem(LS_SELECTED_KEY);
      if (!raw) return null;
      var data = JSON.parse(raw);
      var k = getStorageKey(projectId, yearIndex);
      var arr = data[k];
      return Array.isArray(arr) ? arr : null;
    } catch (e) { return null; }
  }

  function saveSelectedRows(projectId, yearIndex, rowIds) {
    try {
      var raw = localStorage.getItem(LS_SELECTED_KEY);
      var data = raw ? JSON.parse(raw) : {};
      var k = getStorageKey(projectId, yearIndex);
      data[k] = Array.from(rowIds);
      localStorage.setItem(LS_SELECTED_KEY, JSON.stringify(data));
    } catch (e) {}
  }

  function loadForm() {
    try {
      var v = localStorage.getItem(LS_FORM_KEY);
      return (v === 'form2') ? 'form2' : 'form1';
    } catch (e) { return 'form1'; }
  }

  function saveForm(v) {
    try { localStorage.setItem(LS_FORM_KEY, v); } catch (e) {}
  }

  function loadOverrides(key) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : {};
    } catch (e) { return {}; }
  }

  function saveOverrides(key, obj) {
    try { localStorage.setItem(key, JSON.stringify(obj)); } catch (e) {}
  }

  // ========================================================================
  // 행 → 표 데이터 변환
  // ========================================================================
  /**
   * 현재 연차의 row들을 표 양식에 맞게 가공.
   * @returns {Array} 각 항목 = { rowId, personId, included, mapped: {...} }
   */
  function buildRowDataset() {
    var api = window.__pbExport;
    if (!api) return [];
    var project = api.getProject();
    if (!project) return [];
    var year = api.getCurrentYear();
    var rows = api.getRows() || [];

    var defaultPeriod = '';
    if (project.startDate && project.endDate) {
      defaultPeriod = fmtPeriodYM(project.startDate, project.endDate);
    } else if (year && year.period) {
      defaultPeriod = fmtPeriodYM(year.period.startDate, year.period.endDate);
    }

    var selectedIds = _state.selectedRowIds; // Set | null

    return rows.map(function (row, idx) {
      var person = row.personId ? api.getPersonById(row.personId) : null;
      var included = selectedIds ? selectedIds.has(row.id) : true;

      var monthly  = Number(row.actualPay) || Number(row.monthlySalary) || (person && person.monthlySalary) || 0;
      var annual   = monthly * 12; // 급여총액(A)
      var rate     = Number(row.rate) || 0;
      var months   = Number(row.participMonths) || 0;
      // 합계 = (A/12) × B × (C/100) = monthly × months × rate/100
      var total    = Math.round(monthly * months * rate / 100);

      // 참여기간: 인력별 오버라이드 → 프로젝트 기본
      var period = _state.periodOverride[row.id] || defaultPeriod;
      // 담당역할: row.role > export 오버라이드
      var role = (row.role && row.role.trim()) || _state.roleOverride[row.id] || '';

      // 청년/신규 컬럼 라벨
      var newOrExist = row.newOrExisting || (person && person.isNew ? '신규' : '기존');
      var youthLabel = '';
      if (person && person.isYouth) {
        youthLabel = (newOrExist === '신규') ? '신규(청년)' : '청년';
      } else {
        youthLabel = newOrExist === '신규' ? '신규' : '기존';
      }

      // 학위
      var degree = (person && person.finalDegree) || '';
      var major  = (person && person.major) || '';
      var degYr  = '';
      if (person && person.degreeDate) {
        degYr = String(person.degreeDate).slice(0, 4);
      }

      // 생년월일 / 성별 → "YYYY.MM.DD(남/여)" 표기
      var birth = (person && person.birthDate) || '';
      var gender = person ? genderLabel(person.gender) : '';
      var birthGender = birth
        ? (fmtDateCompact(birth) + (gender ? '(' + gender + ')' : ''))
        : (gender ? '(' + gender + ')' : '');

      // 성명(국적) → 일단 국적 데이터가 없으므로 (한국)
      var nameNat = (row.personName || (person && person.name) || '') + '(한국)';

      // 소속기관(역할): 회사 + role 으로 구성. 단, 표1은 [소속기관(역할)] 한 컬럼.
      var company = (person && person.company) || project.company || '';
      var orgRole = company + (role ? '(' + role + ')' : '');

      // 직위
      var position = row.position || (person && person.position) || '';

      // 인력 구분(표2): "내부 / 기존(청년)" 식
      var personType  = '내부'; // 외부 데이터가 없으면 기본 내부
      var newDetail   = youthLabel; // '기존' | '신규' | '청년' | '신규(청년)'

      return {
        rowId: row.id,
        personId: row.personId || '',
        rowType: row.type || 'normal', // normal | youth_required | youth_additional
        included: included,
        mapped: {
          // 공통
          name:        row.personName || (person && person.name) || '',
          nameNat:     nameNat,
          orgRole:     orgRole,        // 소속기관(역할)
          newOrExist:  youthLabel,     // 기존/신규(청년/일반)/시간선택/외부
          position:    position,
          birthGender: birthGender,
          // 학위
          degree:      degree,
          major:       major,
          degreeYear:  degYr,
          // 역할/기간
          role:        role,
          period:      period,
          // 인건비계상률
          rateA:       rate,           // 본 연구개발사업
          rateB:       0,              // 타 사업 (현재 데이터 없음)
          rateAB:      rate,
          projectCnt:  '',             // 국가연구개발사업 수
          // 표2 추가 컬럼
          personType:  personType,     // 인력 구분
          inOut:       '내부',         // 내외부 및 지원구분
          annualSalary: annual,        // 급여총액(A)
          months:      months,         // 참여기간(B, 개월)
          rateC:       rate,           // 해당 차수 인건비계상률(C)
          totalCash:   row.cashOrInkind === '현금' ? total : 0,
          totalInkind: row.cashOrInkind === '현물' ? total : 0,
          totalSum:    total,
        },
      };
    });
  }

  /**
   * 표1 (참여연구원 현황) 헤더 정의.
   * 정부 R&D 양식 - 첫 캡처 기준.
   */
  function getForm1HeaderRows() {
    // 2단 헤더. SheetJS도 헤더만 일반 셀로 처리 (병합은 옵션).
    return {
      // 사람이 읽는 헤더
      headers: [
        '번호',
        '소속기관(역할)',
        '기존/신규(청년,일반)·시간선택/외부',
        '성명(국적)',
        '직위',
        '생년월일(성별)',
        '최종학위',
        '전공',
        '취득연도',
        '담당역할',
        '참여기간(년/월)',
        '본 연구개발사업 인건비계상률(%)',
        '타 국가연구개발사업 인건비계상률(%)',
        '전체 인건비계상률 합계(%) (A+B)',
        '국가연구개발사업 수(건) (3차/5공)',
      ],
      // mapped 객체의 키
      keys: [
        '_no', 'orgRole', 'newOrExist', 'nameNat', 'position',
        'birthGender', 'degree', 'major', 'degreeYear', 'role',
        'period', 'rateA', 'rateB', 'rateAB', 'projectCnt',
      ],
    };
  }

  /**
   * 표2 (인건비 계상 합계) 헤더 정의.
   * 두 번째 캡처: 인력구분 / 성명(국적) / 직위 / 내외부 / 기존·신규 / 급여총액(A)
   *               / 참여기간(B,개월) / 인건비계상률(C) / 합계(현금/현물/계)
   */
  function getForm2HeaderRows() {
    return {
      headers: [
        '인력구분',
        '성명(국적)',
        '직위',
        '내·외부 및 지원구분',
        '기존/신규(청년,일반)·시간선택/외부',
        '급여총액(A)',
        '참여기간 (B, 개월)',
        '해당 차수 인건비계상률(%) (C)',
        '합계 현금 ((A/12)×B×(C/100))',
        '합계 현물',
        '합계 계',
      ],
      keys: [
        'personType', 'nameNat', 'position', 'inOut', 'newOrExist',
        'annualSalary', 'months', 'rateC',
        'totalCash', 'totalInkind', 'totalSum',
      ],
    };
  }

  /**
   * 포함된(included=true) 행만 가지고, 양식에 맞춰 2D 배열 형태로 변환.
   * 표 미리보기 + 엑셀 + HWPX 가 같은 데이터를 공유.
   * @returns {{ headers: string[], rows: any[][], money: Set<number> }}
   */
  function buildTableMatrix() {
    var dataset = buildRowDataset().filter(function (d) { return d.included; });
    var spec = (_state.form === 'form2') ? getForm2HeaderRows() : getForm1HeaderRows();

    var rows = dataset.map(function (d, i) {
      var row = [];
      spec.keys.forEach(function (k) {
        if (k === '_no') {
          row.push(String(i + 1));
        } else {
          row.push(d.mapped[k] == null ? '' : d.mapped[k]);
        }
      });
      return row;
    });

    // 표2 합계 행 추가
    if (_state.form === 'form2' && rows.length > 0) {
      var sumAnnual = 0, sumMonths = 0, sumCash = 0, sumInkind = 0, sumTotal = 0;
      dataset.forEach(function (d) {
        sumAnnual += Number(d.mapped.annualSalary) || 0;
        sumMonths += Number(d.mapped.months) || 0;
        sumCash += Number(d.mapped.totalCash) || 0;
        sumInkind += Number(d.mapped.totalInkind) || 0;
        sumTotal += Number(d.mapped.totalSum) || 0;
      });
      rows.push([
        '합계', '', '', '', '',
        sumAnnual, sumMonths, '',
        sumCash, sumInkind, sumTotal,
      ]);
    }

    // 금액 컬럼 인덱스 (스타일링용)
    var moneyColIdx = new Set();
    if (_state.form === 'form2') {
      // 급여총액(5), 합계 현금(8), 현물(9), 계(10)
      [5, 8, 9, 10].forEach(function (i) { moneyColIdx.add(i); });
    }

    return { headers: spec.headers, rows: rows, money: moneyColIdx };
  }

  // ========================================================================
  // 미리보기 렌더링
  // ========================================================================
  function renderPreview() {
    var wrap = $('pb-export-preview');
    if (!wrap) return;

    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();

    if (!project || !year) {
      wrap.innerHTML = '<div class="pb-export-empty">과제와 연차를 먼저 선택해 주세요.</div>';
      return;
    }

    // 인력 체크리스트
    renderRowCheckList();

    var m = buildTableMatrix();
    if (m.rows.length === 0) {
      wrap.innerHTML = '<div class="pb-export-empty">표시할 인력이 없습니다. (체크박스로 인력을 선택해 주세요)</div>';
      return;
    }

    var html = '';
    html += '<div class="pb-export-table-title">' + escapeHtml(getTableTitle()) + '</div>';
    html += '<table class="pb-export-table"><thead><tr>';
    m.headers.forEach(function (h) {
      html += '<th>' + escapeHtml(h) + '</th>';
    });
    html += '</tr></thead><tbody>';
    m.rows.forEach(function (r, ri) {
      var isSum = (_state.form === 'form2') && (ri === m.rows.length - 1);
      html += isSum ? '<tr class="pb-export-row--sum">' : '<tr>';
      r.forEach(function (cell, ci) {
        var v = cell;
        if (m.money.has(ci) && typeof v === 'number') {
          v = fmtMoney(v);
        }
        html += '<td>' + escapeHtml(v) + '</td>';
      });
      html += '</tr>';
    });
    html += '</tbody></table>';
    wrap.innerHTML = html;
  }

  function getTableTitle() {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    var formName = (_state.form === 'form2') ? '인건비 계상 합계' : '참여연구원 현황';
    var projName = project ? (project.projectName || '') : '';
    var yi = year ? year.yearIndex : 1;
    return '[' + projName + '] ' + yi + '차년도 ' + formName;
  }

  function renderRowCheckList() {
    var list = $('pb-export-row-list');
    if (!list) return;
    var api = window.__pbExport;
    var rows = api ? api.getRows() : [];

    if (!rows.length) {
      list.innerHTML = '<div class="pb-export-empty">예산 표에 행이 없습니다.</div>';
      return;
    }

    var selected = _state.selectedRowIds;
    var html = rows.map(function (row) {
      var person = row.personId ? api.getPersonById(row.personId) : null;
      var name = row.personName || (person && person.name) || '<이름 미입력>';
      var checked = selected ? selected.has(row.id) : true;
      var typeBadge = '';
      if (row.type === 'youth_required') typeBadge = '<span class="pb-export-badge pb-export-badge--req">청년필수</span>';
      else if (row.type === 'youth_additional') typeBadge = '<span class="pb-export-badge pb-export-badge--add">청년추가</span>';
      var months = Number(row.participMonths) || 0;
      var rate = Number(row.rate) || 0;
      var sub = months + '개월 · ' + rate + '%';
      return '' +
        '<label class="pb-export-row-item">' +
          '<input type="checkbox" class="pb-export-row-cb" data-row-id="' + escapeHtml(row.id) + '"' + (checked ? ' checked' : '') + '>' +
          '<span class="pb-export-row-name">' + escapeHtml(name) + '</span>' +
          typeBadge +
          '<span class="pb-export-row-sub">' + escapeHtml(sub) + '</span>' +
        '</label>';
    }).join('');

    list.innerHTML = html;

    // 체크박스 이벤트
    list.querySelectorAll('.pb-export-row-cb').forEach(function (cb) {
      cb.addEventListener('change', function () {
        var rid = cb.dataset.rowId;
        if (!_state.selectedRowIds) {
          // 처음 토글하면 현재 전체 체크 상태에서 시작
          _state.selectedRowIds = new Set(rows.map(function (r) { return r.id; }));
        }
        if (cb.checked) {
          _state.selectedRowIds.add(rid);
        } else {
          _state.selectedRowIds.delete(rid);
        }
        persistSelection();
        renderPreview();
      });
    });
  }

  function persistSelection() {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    if (!project || !year) return;
    if (_state.selectedRowIds) {
      saveSelectedRows(project.id, year.yearIndex, _state.selectedRowIds);
    }
  }

  function restoreSelection() {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    var rows = api ? api.getRows() : [];
    if (!project || !year) {
      _state.selectedRowIds = null;
      return;
    }
    var saved = loadSelectedRows(project.id, year.yearIndex);
    if (saved && rows.length > 0) {
      // 현재 존재하는 row id만 필터
      var validIds = new Set(rows.map(function (r) { return r.id; }));
      _state.selectedRowIds = new Set(saved.filter(function (rid) { return validIds.has(rid); }));
    } else {
      _state.selectedRowIds = null; // 전체 선택
    }
  }

  // 외부에서 호출: 데이터 갱신 시 미리보기 새로 그리기
  function refresh() {
    restoreSelection();
    renderPreview();
  }

  // ========================================================================
  // 엑셀 다운로드
  // ========================================================================
  function downloadExcel() {
    if (typeof XLSX === 'undefined') {
      toast('엑셀 라이브러리를 로드하지 못했습니다.', true);
      return;
    }
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    if (!project || !year) {
      toast('과제와 연차를 먼저 선택해 주세요.', true);
      return;
    }

    var m = buildTableMatrix();
    if (m.rows.length === 0) {
      toast('내보낼 데이터가 없습니다.', true);
      return;
    }

    // 시트 데이터: 제목 + 빈줄 + 헤더 + 데이터
    var aoa = [];
    aoa.push([getTableTitle()]);
    aoa.push([]);
    aoa.push(m.headers);
    m.rows.forEach(function (r) {
      aoa.push(r.slice());
    });

    var ws = XLSX.utils.aoa_to_sheet(aoa);

    // 열 너비 (대략)
    var colCount = m.headers.length;
    var colWidths = [];
    for (var c = 0; c < colCount; c++) {
      var h = m.headers[c] || '';
      var width = Math.min(Math.max(h.length * 2.2 + 4, 10), 24);
      colWidths.push({ wch: width });
    }
    ws['!cols'] = colWidths;

    // 제목 행 병합 (A1:끝열1)
    ws['!merges'] = ws['!merges'] || [];
    ws['!merges'].push({
      s: { r: 0, c: 0 },
      e: { r: 0, c: colCount - 1 },
    });

    // 숫자 셀 포맷 (money 컬럼)
    m.rows.forEach(function (r, ri) {
      r.forEach(function (cell, ci) {
        if (m.money.has(ci) && typeof cell === 'number') {
          var addr = XLSX.utils.encode_cell({ r: ri + 3, c: ci }); // +3: 제목+빈+헤더
          if (ws[addr]) {
            ws[addr].t = 'n';
            ws[addr].z = '#,##0';
          }
        }
      });
    });

    var wb = XLSX.utils.book_new();
    var sheetName = (_state.form === 'form2') ? '인건비계상합계' : '참여연구원현황';
    XLSX.utils.book_append_sheet(wb, ws, sheetName);

    var fname = makeFilename('xlsx');
    XLSX.writeFile(wb, fname);
    toast('엑셀 다운로드 완료');
  }

  function makeFilename(ext) {
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    var projName = project ? (project.projectName || 'project') : 'project';
    var yi = year ? year.yearIndex : 1;
    var formName = (_state.form === 'form2') ? '인건비계상합계' : '참여연구원현황';
    // 파일명 안전화
    var safe = projName.replace(/[\\/:*?"<>|]/g, '_');
    var today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    return safe + '_' + yi + '차년도_' + formName + '_' + today + '.' + ext;
  }

  // ========================================================================
  // HWPX 다운로드
  // ========================================================================
  /**
   * HWPX = ZIP 패키지로 다음 파일을 포함:
   *   - mimetype                          (STORED 압축 안 함)
   *   - META-INF/container.xml
   *   - META-INF/manifest.xml
   *   - Contents/content.hpf
   *   - Contents/header.xml
   *   - Contents/section0.xml
   *   - version.xml
   *   - settings.xml (옵션)
   *
   * 최소 유효 패키지를 만들어 한글 2014+에서 열 수 있도록 구성.
   * 표는 hp:tbl > hp:tr > hp:tc > hp:subList > hp:p > hp:run > hp:t 구조.
   */
  function downloadHwpx() {
    if (typeof JSZip === 'undefined') {
      toast('JSZip 라이브러리를 로드하지 못했습니다.', true);
      return;
    }
    var api = window.__pbExport;
    var project = api && api.getProject();
    var year = api && api.getCurrentYear();
    if (!project || !year) {
      toast('과제와 연차를 먼저 선택해 주세요.', true);
      return;
    }

    var m = buildTableMatrix();
    if (m.rows.length === 0) {
      toast('내보낼 데이터가 없습니다.', true);
      return;
    }

    var zip = new JSZip();

    // mimetype - 항상 무압축 STORED
    zip.file('mimetype', 'application/hwp+zip', { compression: 'STORE' });

    // META-INF/container.xml
    zip.folder('META-INF').file('container.xml', buildContainerXml());
    zip.folder('META-INF').file('manifest.xml', buildManifestXml());

    // Contents/
    var contents = zip.folder('Contents');
    contents.file('content.hpf', buildContentHpf());
    contents.file('header.xml', buildHeaderXml());
    contents.file('section0.xml', buildSection0Xml(m));

    // version.xml
    zip.file('version.xml', buildVersionXml());

    zip.generateAsync({
      type: 'blob',
      mimeType: 'application/hwp+zip',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    }).then(function (blob) {
      var fname = makeFilename('hwpx');
      downloadBlob(blob, fname);
      toast('한글(HWPX) 다운로드 완료');
    }).catch(function (err) {
      console.error('[HWPX] generate error', err);
      toast('한글 파일 생성에 실패했습니다.', true);
    });
  }

  // ----- HWPX XML 빌더들 -----

  function buildContainerXml() {
    return '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<ocf:container xmlns:ocf="urn:oasis:names:tc:opendocument:xmlns:container">\n' +
      '  <ocf:rootfiles>\n' +
      '    <ocf:rootfile full-path="Contents/content.hpf" media-type="application/hwpml-package+xml"/>\n' +
      '  </ocf:rootfiles>\n' +
      '</ocf:container>';
  }

  function buildManifestXml() {
    return '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<manifest xmlns="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0">\n' +
      '  <file-entry full-path="/" media-type="application/hwp+zip"/>\n' +
      '  <file-entry full-path="Contents/content.hpf" media-type="application/hwpml-package+xml"/>\n' +
      '  <file-entry full-path="Contents/header.xml" media-type="application/xml"/>\n' +
      '  <file-entry full-path="Contents/section0.xml" media-type="application/xml"/>\n' +
      '  <file-entry full-path="version.xml" media-type="application/xml"/>\n' +
      '</manifest>';
  }

  function buildVersionXml() {
    return '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<hv:HCFVersion xmlns:hv="http://www.hancom.co.kr/hwpml/2011/version" ' +
      'targetApplication="WORDPROCESSOR" major="5" minor="1" micro="0" buildNumber="0"/>';
  }

  function buildContentHpf() {
    return '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<opf:package xmlns:opf="http://www.idpf.org/2007/opf/" version="1.0" unique-identifier="hwpx-doc">\n' +
      '  <opf:metadata xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opfx="http://www.hancom.co.kr/schema/2011/opf-extension">\n' +
      '    <opf:meta name="generator" content="60hz-rnd-dashboard"/>\n' +
      '    <dc:title>' + escapeXml(getTableTitle()) + '</dc:title>\n' +
      '    <dc:language>ko</dc:language>\n' +
      '  </opf:metadata>\n' +
      '  <opf:manifest>\n' +
      '    <opf:item id="header" href="header.xml" media-type="application/xml"/>\n' +
      '    <opf:item id="section0" href="section0.xml" media-type="application/xml"/>\n' +
      '  </opf:manifest>\n' +
      '  <opf:spine>\n' +
      '    <opf:itemref idref="section0" linear="yes"/>\n' +
      '  </opf:spine>\n' +
      '</opf:package>';
  }

  function buildHeaderXml() {
    return '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<hh:head xmlns:hh="http://www.hancom.co.kr/hwpml/2011/head" ' +
      'xmlns:hc="http://www.hancom.co.kr/hwpml/2011/core" version="1.4" secCnt="1">\n' +
      '  <hh:beginNum page="1" footnote="1" endnote="1" pic="1" tbl="1" equation="1"/>\n' +
      '  <hh:refList>\n' +
      '    <hh:fontfaces itemCnt="1">\n' +
      '      <hh:fontface lang="HANGUL" fontCnt="1"><hh:font id="0" face="함초롬바탕" type="TTF"/></hh:fontface>\n' +
      '    </hh:fontfaces>\n' +
      '    <hh:borderFills itemCnt="2">\n' +
      '      <hh:borderFill id="1" threeD="0" shadow="0" centerLine="NONE" breakCellSeparateLine="0">\n' +
      '        <hh:slash type="NONE" Crooked="0" isCounter="0"/>\n' +
      '        <hh:backSlash type="NONE" Crooked="0" isCounter="0"/>\n' +
      '        <hh:leftBorder type="SOLID" width="0.12 mm" color="#000000"/>\n' +
      '        <hh:rightBorder type="SOLID" width="0.12 mm" color="#000000"/>\n' +
      '        <hh:topBorder type="SOLID" width="0.12 mm" color="#000000"/>\n' +
      '        <hh:bottomBorder type="SOLID" width="0.12 mm" color="#000000"/>\n' +
      '        <hh:diagonal type="SOLID" width="0.1 mm" color="#000000"/>\n' +
      '      </hh:borderFill>\n' +
      '      <hh:borderFill id="2" threeD="0" shadow="0" centerLine="NONE" breakCellSeparateLine="0">\n' +
      '        <hh:slash type="NONE" Crooked="0" isCounter="0"/>\n' +
      '        <hh:backSlash type="NONE" Crooked="0" isCounter="0"/>\n' +
      '        <hh:leftBorder type="SOLID" width="0.12 mm" color="#000000"/>\n' +
      '        <hh:rightBorder type="SOLID" width="0.12 mm" color="#000000"/>\n' +
      '        <hh:topBorder type="SOLID" width="0.12 mm" color="#000000"/>\n' +
      '        <hh:bottomBorder type="SOLID" width="0.12 mm" color="#000000"/>\n' +
      '        <hh:diagonal type="SOLID" width="0.1 mm" color="#000000"/>\n' +
      '        <hh:fillBrush>\n' +
      '          <hh:winBrush faceColor="#E5E7EB" hatchColor="#000000" hatchStyle="NONE" alpha="0"/>\n' +
      '        </hh:fillBrush>\n' +
      '      </hh:borderFill>\n' +
      '    </hh:borderFills>\n' +
      '    <hh:charProperties itemCnt="2">\n' +
      '      <hh:charPr id="0" height="1000" textColor="#000000" shadeColor="none" useFontSpace="0" useKerning="0" symMark="NONE" borderFillIDRef="0">\n' +
      '        <hh:fontRef hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>\n' +
      '        <hh:ratio hangul="100" latin="100" hanja="100" japanese="100" other="100" symbol="100" user="100"/>\n' +
      '        <hh:spacing hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>\n' +
      '        <hh:relSz hangul="100" latin="100" hanja="100" japanese="100" other="100" symbol="100" user="100"/>\n' +
      '        <hh:offset hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>\n' +
      '      </hh:charPr>\n' +
      '      <hh:charPr id="1" height="1100" textColor="#000000" shadeColor="none" useFontSpace="0" useKerning="0" symMark="NONE" borderFillIDRef="0" bold="1">\n' +
      '        <hh:fontRef hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>\n' +
      '        <hh:ratio hangul="100" latin="100" hanja="100" japanese="100" other="100" symbol="100" user="100"/>\n' +
      '        <hh:spacing hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>\n' +
      '        <hh:relSz hangul="100" latin="100" hanja="100" japanese="100" other="100" symbol="100" user="100"/>\n' +
      '        <hh:offset hangul="0" latin="0" hanja="0" japanese="0" other="0" symbol="0" user="0"/>\n' +
      '      </hh:charPr>\n' +
      '    </hh:charProperties>\n' +
      '    <hh:paraProperties itemCnt="1">\n' +
      '      <hh:paraPr id="0" tabPrIDRef="0" condense="0" fontLineHeight="0" snapToGrid="1" suppressLineNumbers="0" checked="0">\n' +
      '        <hh:align horizontal="JUSTIFY" vertical="BASELINE"/>\n' +
      '        <hh:heading type="NONE" idRef="0" level="0"/>\n' +
      '        <hh:breakSetting breakLatinWord="KEEP_WORD" breakNonLatinWord="KEEP_WORD" widowOrphan="0" keepWithNext="0" keepLines="0" pageBreakBefore="0" lineWrap="BREAK"/>\n' +
      '        <hh:margin>\n' +
      '          <hc:intent value="0"/><hc:left value="0"/><hc:right value="0"/><hc:prev value="0"/><hc:next value="0"/>\n' +
      '        </hh:margin>\n' +
      '        <hh:lineSpacing type="PERCENT" value="160" unit="HWPUNIT"/>\n' +
      '        <hh:border borderFillIDRef="0" offsetLeft="0" offsetRight="0" offsetTop="0" offsetBottom="0" connect="0" ignoreMargin="0"/>\n' +
      '        <hh:autoSpacing eAsianEng="0" eAsianNum="0"/>\n' +
      '      </hh:paraPr>\n' +
      '    </hh:paraProperties>\n' +
      '    <hh:styles itemCnt="1">\n' +
      '      <hh:style id="0" type="PARA" name="바탕글" engName="Normal" paraPrIDRef="0" charPrIDRef="0" nextStyleIDRef="0" langID="1042" lockForm="0"/>\n' +
      '    </hh:styles>\n' +
      '  </hh:refList>\n' +
      '  <hh:compatibleDocument targetProgram="HWP201X">\n' +
      '    <hh:layoutCompatibility textWrap="0" tableCellApply="0" image="0" arc="0"/>\n' +
      '  </hh:compatibleDocument>\n' +
      '  <hh:docOption>\n' +
      '    <hh:linkinfo path="" pageInherit="0" footnoteInherit="0"/>\n' +
      '  </hh:docOption>\n' +
      '</hh:head>';
  }

  /**
   * 표 한 셀의 hp:tc XML 생성.
   * @param {string} text - 셀 내용
   * @param {object} opts - { isHeader: bool, colSpan: number, rowSpan: number }
   */
  function buildHwpxCell(text, opts) {
    opts = opts || {};
    var borderId = opts.isHeader ? '2' : '1';
    var charPrId = opts.isHeader ? '1' : '0';
    var safeText = String(text == null ? '' : text);

    // 줄바꿈 처리 - 일단 공백으로 (테이블 셀 줄바꿈은 hp:p 분리 필요)
    safeText = safeText.replace(/\r?\n/g, ' ');

    return '' +
      '<hp:tc name="" header="' + (opts.isHeader ? '1' : '0') + '" hasMargin="0" protect="0" editable="0" dirty="0" borderFillIDRef="' + borderId + '">' +
        '<hp:subList id="" textDirection="HORIZONTAL" lineWrap="BREAK" vertAlign="CENTER" linkListIDRef="0" linkListNextIDRef="0" textWidth="0" textHeight="0" hasTextRef="0" hasNumRef="0">' +
          '<hp:p id="0" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">' +
            '<hp:run charPrIDRef="' + charPrId + '">' +
              '<hp:t>' + escapeXml(safeText) + '</hp:t>' +
            '</hp:run>' +
            '<hp:linesegarray>' +
              '<hp:lineseg textpos="0" vertpos="0" vertsize="' + (opts.isHeader ? '1100' : '1000') + '" textheight="' + (opts.isHeader ? '1100' : '1000') + '" baseline="850" spacing="600" horzpos="0" horzsize="' + (opts.cellWidth || 1500) + '" flags="393216"/>' +
            '</hp:linesegarray>' +
          '</hp:p>' +
        '</hp:subList>' +
        '<hp:cellAddr colAddr="' + (opts.col || 0) + '" rowAddr="' + (opts.row || 0) + '"/>' +
        '<hp:cellSpan colSpan="' + (opts.colSpan || 1) + '" rowSpan="' + (opts.rowSpan || 1) + '"/>' +
        '<hp:cellSz width="' + (opts.cellWidth || 1500) + '" height="900"/>' +
        '<hp:cellMargin left="141" right="141" top="141" bottom="141"/>' +
      '</hp:tc>';
  }

  function buildSection0Xml(matrix) {
    var headers = matrix.headers;
    var rows    = matrix.rows;
    var moneyCols = matrix.money;

    var totalCols = headers.length;
    // 표 전체 너비 ~ 본문영역 (대략 40000 HWPUNIT = 약 169mm)
    var totalTableWidth = 40000;
    var cellWidth = Math.floor(totalTableWidth / totalCols);

    // 제목 paragraph
    var titleP = '' +
      '<hp:p id="0" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">' +
        '<hp:run charPrIDRef="1">' +
          '<hp:t>' + escapeXml(getTableTitle()) + '</hp:t>' +
        '</hp:run>' +
        '<hp:linesegarray>' +
          '<hp:lineseg textpos="0" vertpos="0" vertsize="1100" textheight="1100" baseline="850" spacing="600" horzpos="0" horzsize="40000" flags="393216"/>' +
        '</hp:linesegarray>' +
      '</hp:p>';

    // 빈 줄
    var emptyP = '' +
      '<hp:p id="0" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">' +
        '<hp:run charPrIDRef="0"/>' +
        '<hp:linesegarray>' +
          '<hp:lineseg textpos="0" vertpos="1200" vertsize="1000" textheight="1000" baseline="850" spacing="600" horzpos="0" horzsize="40000" flags="393216"/>' +
        '</hp:linesegarray>' +
      '</hp:p>';

    // 헤더 행
    var headerRowXml = '<hp:tr>';
    headers.forEach(function (h, c) {
      headerRowXml += buildHwpxCell(h, {
        isHeader: true,
        col: c, row: 0,
        cellWidth: cellWidth,
      });
    });
    headerRowXml += '</hp:tr>';

    // 데이터 행
    var dataRowsXml = rows.map(function (row, ri) {
      var trXml = '<hp:tr>';
      row.forEach(function (cell, c) {
        var v = cell;
        if (moneyCols.has(c) && typeof v === 'number') {
          v = fmtMoney(v);
        }
        var isSumRow = (_state.form === 'form2') && (ri === rows.length - 1);
        trXml += buildHwpxCell(v, {
          isHeader: isSumRow,
          col: c, row: ri + 1,
          cellWidth: cellWidth,
        });
      });
      trXml += '</hp:tr>';
      return trXml;
    }).join('');

    var tableHeight = 900 * (rows.length + 1);

    var tableXml = '' +
      '<hp:tbl id="1" zOrder="0" numberingType="TABLE" textWrap="TOP_AND_BOTTOM" textFlow="BOTH_SIDES" lock="0" dropcapstyle="None" pageBreak="CELL" repeatHeader="1" rowCnt="' + (rows.length + 1) + '" colCnt="' + totalCols + '" cellSpacing="0" borderFillIDRef="1" noAdjust="0">' +
        '<hp:sz width="' + totalTableWidth + '" widthRelTo="ABSOLUTE" height="' + tableHeight + '" heightRelTo="ABSOLUTE" protect="0"/>' +
        '<hp:pos treatAsChar="0" affectLSpacing="0" flowWithText="1" allowOverlap="0" holdAnchorAndSO="0" vertRelTo="PARA" horzRelTo="COLUMN" vertAlign="TOP" horzAlign="CENTER" vertOffset="0" horzOffset="0"/>' +
        '<hp:outMargin left="283" right="283" top="283" bottom="283"/>' +
        '<hp:inMargin left="141" right="141" top="141" bottom="141"/>' +
        headerRowXml + dataRowsXml +
      '</hp:tbl>';

    // 표를 감싸는 paragraph
    var tableP = '' +
      '<hp:p id="0" paraPrIDRef="0" styleIDRef="0" pageBreak="0" columnBreak="0" merged="0">' +
        '<hp:run charPrIDRef="0">' +
          tableXml +
        '</hp:run>' +
        '<hp:linesegarray>' +
          '<hp:lineseg textpos="0" vertpos="2400" vertsize="' + tableHeight + '" textheight="' + tableHeight + '" baseline="850" spacing="600" horzpos="0" horzsize="40000" flags="393216"/>' +
        '</hp:linesegarray>' +
      '</hp:p>';

    return '<?xml version="1.0" encoding="UTF-8"?>\n' +
      '<hs:sec xmlns:hs="http://www.hancom.co.kr/hwpml/2011/section" ' +
      'xmlns:hp="http://www.hancom.co.kr/hwpml/2011/paragraph" ' +
      'xmlns:hh="http://www.hancom.co.kr/hwpml/2011/head" ' +
      'xmlns:hc="http://www.hancom.co.kr/hwpml/2011/core">\n' +
      titleP + emptyP + tableP +
      '</hs:sec>';
  }

  // ========================================================================
  // 이벤트 바인딩
  // ========================================================================
  function bindEvents() {
    // 양식 드롭다운
    var formSel = $('pb-export-form-select');
    if (formSel) {
      formSel.value = _state.form;
      formSel.addEventListener('change', function () {
        _state.form = formSel.value;
        saveForm(_state.form);
        renderPreview();
      });
    }

    // 다운로드 버튼
    var xlsxBtn = $('pb-export-xlsx-btn');
    if (xlsxBtn) xlsxBtn.addEventListener('click', downloadExcel);

    var hwpxBtn = $('pb-export-hwpx-btn');
    if (hwpxBtn) hwpxBtn.addEventListener('click', downloadHwpx);

    // 전체 선택 / 해제
    var selAllBtn = $('pb-export-select-all');
    var unselAllBtn = $('pb-export-unselect-all');
    if (selAllBtn) {
      selAllBtn.addEventListener('click', function () {
        var api = window.__pbExport;
        var rows = api ? api.getRows() : [];
        _state.selectedRowIds = new Set(rows.map(function (r) { return r.id; }));
        persistSelection();
        renderPreview();
      });
    }
    if (unselAllBtn) {
      unselAllBtn.addEventListener('click', function () {
        _state.selectedRowIds = new Set();
        persistSelection();
        renderPreview();
      });
    }
  }

  // ========================================================================
  // 초기화 - project-budget.js가 준비된 후 호출됨
  // ========================================================================
  function init() {
    _state.form = loadForm();
    _state.periodOverride = loadOverrides(LS_PERIOD_KEY);
    _state.roleOverride = loadOverrides(LS_ROLE_KEY);

    bindEvents();
    refresh();

    // project-budget.js가 데이터 갱신 시 호출하도록 노출
    window.__pbExportRefresh = refresh;
  }

  // project-budget.js가 노출하는 API가 준비될 때까지 기다림
  function waitForApi() {
    if (window.__pbExport) {
      init();
    } else {
      setTimeout(waitForApi, 50);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', waitForApi);
  } else {
    waitForApi();
  }

})();

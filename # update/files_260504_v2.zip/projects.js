/**
 * 과제 관리 페이지 - Firestore 실시간 연동
 */
(function () {
  'use strict';

  var CUTOFF = '2026-01-01';
  var STAT_YEAR = 2026;
  var COL_KEYS = ['부처', '예산', '과제명', '기관명', '연구기간', '지원금당해', '지원금총', '비고'];

  function projectOverlapsYear(it, year) {
    var y = String(year);
    var start = (it.startDate || it.start || '').toString().slice(0, 10);
    var end = (it.endDate || it.end || '').toString().slice(0, 10);
    if (!start && !end) return true;
    var yearStart = y + '-01-01';
    var yearEnd = y + '-12-31';
    if (start && start > yearEnd) return false;
    if (end && end < yearStart) return false;
    return true;
  }
  var COL_FIELDS = { '부처': 'department', '예산': 'budget', '과제명': 'projectName', '기관명': 'institution', '연구기간': 'researchPeriod', '지원금당해': 'supportYear', '지원금총': 'supportTotal', '비고': 'note' };

  function getVal(item, key) {
    var f = COL_FIELDS[key];
    return item[f] != null ? String(item[f]) : (item[key] != null ? String(item[key]) : '');
  }

  function getResearchPeriodDisplay(item, filterYear) {
    var fallbackStart = (item.startDate || item.start || '').toString().slice(0, 10);
    var fallbackEnd = (item.endDate || item.end || '').toString().slice(0, 10);
    var yearStr = filterYear ? String(filterYear) : null;
    var arr = item.annualData || item.yearBudgets || [];
    if (!Array.isArray(arr)) arr = [];
    for (var i = 0; i < arr.length; i++) {
      var y = arr[i];
      var s = (y.start || y.startDate || '').toString().slice(0, 10);
      var e = (y.end || y.endDate || '').toString().slice(0, 10);
      if (!s && !e) continue;
      var sYear = s ? s.slice(0, 4) : '';
      var eYear = e ? e.slice(0, 4) : '';
      if (yearStr && sYear && eYear && sYear <= yearStr && yearStr <= eYear) {
        return (s || '-') + ' ~ ' + (e || '-');
      }
    }
    if (fallbackStart || fallbackEnd) return (fallbackStart || '-') + ' ~ ' + (fallbackEnd || '-');
    return '-';
  }

  function getDivision2Class(status) {
    var s = (status || '').trim().toLowerCase();
    if (s === '종료') return 'projects-badge--end';
    if (s === '수행 중' || s === '수행중') return 'projects-badge--ongoing';
    if (s === '예정') return 'projects-badge--scheduled';
    if (s === '미선정') return 'projects-badge--unselected';
    return 'projects-badge--end';
  }

  function getKeywordHtml(item) {
    var isRd = item.isRd === true || item.rd === true || item['R&D 여부'] === true;
    var kw = item.keywords || item.keyword || '';
    if (typeof kw !== 'string') kw = Array.isArray(kw) ? kw.join(', ') : String(kw);
    var rdTag = isRd ? '<span class="projects-badge projects-badge--rd">[R&D]</span>' : '';
    return rdTag + escapeHtml(kw || '-');
  }

  function escapeHtml(s) {
    if (s == null) return '';
    var div = document.createElement('div');
    div.textContent = s;
    return div.innerHTML;
  }

  function formatNum(n) {
    if (n == null || n === '' || isNaN(Number(n))) return '0';
    return Number(n).toLocaleString();
  }

  function updateStats(items, year) {
    year = year || STAT_YEAR;
    var filtered = items.filter(function (it) { return projectOverlapsYear(it, year); });
    var total = filtered.length;
    var continueCnt = 0;
    var newCnt = 0;
    var unselectedCnt = 0;
    var yearSum = 0;
    var totalSum = 0;
    var cutoff = year + '-01-01';

    filtered.forEach(function (it) {
      var start = (it.startDate || it.start || '').toString().slice(0, 10);
      var status = (it.status || it['진행 여부'] || it.division2 || '').toString().trim();
      var statusNorm = status.replace(/\s/g, '');
      if (statusNorm === '수행중' || status === '수행 중') {
        if (start && start < cutoff) continueCnt++;
        else newCnt++;
      }
      if (statusNorm === '미선정' || status === '미선정') unselectedCnt++;

      var sy = 0;
      if (Number(year) === 2026 && it.supportYear != null && !isNaN(Number(it.supportYear))) {
        sy = Number(it.supportYear);
      } else if (it.yearBudgets && Array.isArray(it.yearBudgets)) {
        it.yearBudgets.forEach(function (y) {
          var s = (y.startDate || '').slice(0, 4);
          var e = (y.endDate || '').slice(0, 4);
          if ((s && s <= String(year)) && (e && e >= String(year))) sy += Number(y.support || 0);
        });
      }
      yearSum += sy;
      var st = it.supportTotal != null ? Number(it.supportTotal) : (it.budget != null ? Number(it.budget) : 0);
      if (!isNaN(st)) totalSum += st;
    });

    setEl('stat-total', total);
    setEl('stat-continue', continueCnt);
    setEl('stat-new', newCnt);
    setEl('stat-unselected', unselectedCnt);
    setEl('stat-year-sum', formatNum(yearSum));
    setEl('stat-total-sum', formatNum(totalSum));
  }

  function setEl(id, val) {
    var el = document.getElementById(id);
    if (el) el.textContent = val;
  }

  function getColVisibility() {
    var vis = {};
    COL_KEYS.forEach(function (k) {
      var cb = document.querySelector('#col-panel input[data-col="' + k + '"]');
      vis[k] = cb ? cb.checked : false;
    });
    return vis;
  }

  function saveColVisibility(vis) {
    COL_KEYS.forEach(function (k) {
      var cb = document.querySelector('#col-panel input[data-col="' + k + '"]');
      if (cb) cb.checked = !!vis[k];
    });
  }

  function loadColVisibility() {
    try {
      var raw = localStorage.getItem('projects-col-visibility');
      if (raw) {
        var vis = JSON.parse(raw);
        saveColVisibility(vis);
      }
    } catch (e) {}
  }

  function applyColVisibility(vis) {
    var ths = document.querySelectorAll('#projects-table thead th.col-opt');
    var rows = document.querySelectorAll('#projects-table tbody tr');
    var showVal = 'table-cell';
    ths.forEach(function (th) {
      var col = th.getAttribute('data-col');
      var show = vis[col];
      th.style.display = show ? showVal : 'none';
    });
    rows.forEach(function (tr) {
      var cells = tr.querySelectorAll('td.col-opt');
      cells.forEach(function (td) {
        var col = td.getAttribute('data-col');
        var show = vis[col];
        td.style.display = show ? showVal : 'none';
      });
    });
  }

  function renderTable(items, colVis, filterYear, onEdit) {
    var tbody = document.getElementById('projects-tbody');
    if (!tbody) return;

    tbody.innerHTML = '';
    items.forEach(function (it, idx) {
      var id = it.id || it.docId || 'item-' + idx;
      var start = (it.startDate || it.start || '').toString().slice(0, 10);
      var end = (it.endDate || it.end || '').toString().slice(0, 10);
      var div1 = (it.division1 || '').toString() || (start && start < CUTOFF ? '계속' : (start ? '신규' : '-'));
      var div2 = (it.division2 || '').toString() || (start && start < CUTOFF ? '계속' : (start ? '신규' : '-'));
      var status = (it.status || it['진행 여부'] || it.division2 || '').toString();
      var badgeClass = getDivision2Class(status);
      var div1Display = div1 === '신규' ? '<strong>[신규]</strong>' : escapeHtml(div1 || '-');

      var tr = document.createElement('tr');
      tr.setAttribute('data-id', id);

      var no = (it.no != null && it.no !== '') ? String(it.no) : (idx + 1);
      var cells = [
        '<td>' + escapeHtml(no) + '</td>',
        '<td>' + div1Display + '</td>',
        '<td>' + escapeHtml(div2 || '-') + '</td>',
        '<td><span class="projects-badge ' + badgeClass + '">' + escapeHtml(status || '-') + '</span></td>',
        '<td>' + getKeywordHtml(it) + '</td>',
        '<td>' + escapeHtml(it.manager || it.책임자 || '-') + '</td>',
        '<td>' + escapeHtml(start || '-') + '</td>',
        '<td>' + escapeHtml(end || '-') + '</td>'
      ];

      COL_KEYS.forEach(function (k) {
        var val = k === '연구기간' ? getResearchPeriodDisplay(it, filterYear) : (getVal(it, k) || '-');
        cells.push('<td class="col-opt" data-col="' + k + '">' + escapeHtml(val) + '</td>');
      });

      cells.push('<td style="text-align:center"><button type="button" class="ui-btn ui-btn--ghost project-edit-btn" data-id="' + escapeHtml(id) + '">수정</button></td>');
      tr.innerHTML = cells.join('');

      var editBtn = tr.querySelector('.project-edit-btn');
      if (editBtn && typeof onEdit === 'function') {
        editBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          onEdit(it);
        });
      }

      tbody.appendChild(tr);
    });

    applyColVisibility(colVis || getColVisibility());
  }

  function init() {
    var sidebar = document.getElementById('sidebar');
    var sidebarToggle = document.getElementById('sidebar-toggle');
    if (sidebar && sidebarToggle) {
      sidebarToggle.addEventListener('click', function () {
        sidebar.classList.toggle('sidebar--collapsed');
        try { localStorage.setItem('hr-sidebar-collapsed', sidebar.classList.contains('sidebar--collapsed') ? '1' : ''); } catch (e) {}
      });
      try { if (localStorage.getItem('hr-sidebar-collapsed') === '1') sidebar.classList.add('sidebar--collapsed'); } catch (e) {}
    }
    loadColVisibility();
    var colVis = getColVisibility();

    var colToggle = document.getElementById('col-toggle-btn');
    var colPanel = document.getElementById('col-panel');
    if (colToggle && colPanel) {
      colToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        colPanel.classList.toggle('open');
      });
      document.addEventListener('click', function () {
        colPanel.classList.remove('open');
      });
      colPanel.addEventListener('click', function (e) {
        e.stopPropagation();
      });
      colPanel.querySelectorAll('input').forEach(function (cb) {
        cb.addEventListener('change', function () {
          var vis = getColVisibility();
          applyColVisibility(vis);
          try { localStorage.setItem('projects-col-visibility', JSON.stringify(vis)); } catch (e) {}
        });
      });
    }

    var svc = window.firestoreService;
    var latestItems = [];
    var yearFilter = document.getElementById('project-year-filter');
    var filterHint = document.getElementById('project-filter-hint');
    var activeFiltersWrap = document.getElementById('project-active-filters');

    // ----- 활성 필터 상태 -----
    // activeCardFilter: 'continue' | 'new' | 'unselected' (카드 클릭으로 활성화)
    // activeStatusFilter: '수행 중' | '예정' | '종료' (URL ?status= 진입 시, 카드와 매칭 안 되는 status용)
    var activeCardFilter = null;
    var activeStatusFilter = null;

    // 페이지 로드 시 URL 파라미터에서 초기 필터 읽기
    (function readInitialFilter() {
      var params = new URLSearchParams(location.search);
      var filter = params.get('filter');
      var status = params.get('status');

      if (filter === 'continue' || filter === 'new' || filter === 'unselected') {
        activeCardFilter = filter;
      }

      if (status) {
        var trimmed = decodeURIComponent(status).trim();
        var trimmedNorm = trimmed.replace(/\s/g, '');
        // 카드와 매칭 가능한 것은 카드 활성화로 매핑
        if (trimmedNorm === '미선정') {
          activeCardFilter = 'unselected';
        } else if (trimmedNorm === '수행중') {
          // '수행 중'은 카드가 계속/신규로 분리되어 있으므로 별도 status 필터 사용
          activeStatusFilter = '수행 중';
        } else if (trimmedNorm === '예정' || trimmedNorm === '종료') {
          activeStatusFilter = trimmed;
        }
      }
    })();

    function getFilterYear() {
      var v = yearFilter ? yearFilter.value : '';
      return v || null;
    }
    function getStatsYear() {
      var y = getFilterYear();
      return y ? parseInt(y, 10) : STAT_YEAR;
    }

    // 카드 필터(continue/new/unselected) 매칭
    function projectMatchesCardFilter(it, filter, cutoff) {
      if (!filter) return true;
      var status = (it.status || it['진행 여부'] || it.division2 || '').toString();
      var statusNorm = status.replace(/\s/g, '');
      var start = (it.startDate || it.start || '').toString().slice(0, 10);
      var isOngoing = statusNorm === '수행중' || status === '수행 중';

      if (filter === 'continue') return isOngoing && !!start && start < cutoff;
      if (filter === 'new')      return isOngoing && (!start || start >= cutoff);
      if (filter === 'unselected') return statusNorm === '미선정';
      return true;
    }

    // status 필터(수행 중/예정/종료) 매칭
    function projectMatchesStatusFilter(it, status) {
      if (!status) return true;
      var s = (it.status || it['진행 여부'] || it.division2 || '').toString().trim();
      var sNorm = s.replace(/\s/g, '');
      var targetNorm = status.replace(/\s/g, '');
      return s === status || sNorm === targetNorm;
    }

    // 카드 활성 상태 UI 동기화
    function updateActiveCardUI() {
      document.querySelectorAll('.projects-stat-card.clickable').forEach(function (card) {
        var f = card.getAttribute('data-filter');
        var isActive = (f === activeCardFilter);
        card.classList.toggle('is-active', isActive);
        card.setAttribute('aria-pressed', isActive ? 'true' : 'false');
      });
    }

    // 활성 필터 chip 렌더
    function renderActiveFilterChip() {
      if (!activeFiltersWrap) return;
      activeFiltersWrap.innerHTML = '';

      var label = null;
      if (activeCardFilter === 'continue')        label = '수행 중 (계속)';
      else if (activeCardFilter === 'new')        label = '수행 중 (신규)';
      else if (activeCardFilter === 'unselected') label = '미선정';
      else if (activeStatusFilter)                 label = activeStatusFilter;

      if (!label) return;

      var chip = document.createElement('span');
      chip.className = 'projects-filter-chip';
      chip.innerHTML = '필터: ' + escapeHtml(label) +
        ' <button type="button" class="projects-filter-chip-clear" aria-label="필터 해제">×</button>';
      activeFiltersWrap.appendChild(chip);

      chip.querySelector('.projects-filter-chip-clear').addEventListener('click', function () {
        activeCardFilter = null;
        activeStatusFilter = null;
        syncURL();
        applyFilterAndRender(latestItems);
      });
    }

    // URL 파라미터 동기화 (페이지 새로고침해도 필터 유지)
    function syncURL() {
      var params = new URLSearchParams(location.search);
      params.delete('filter');
      params.delete('status');
      if (activeCardFilter)   params.set('filter', activeCardFilter);
      if (activeStatusFilter) params.set('status', activeStatusFilter);
      var query = params.toString();
      var newUrl = location.pathname + (query ? '?' + query : '') + location.hash;
      try { history.replaceState(null, '', newUrl); } catch (e) {}
    }

    function applyFilterAndRender(items) {
      items = Array.isArray(items) ? items : [];
      latestItems = items;
      var filterYear = getFilterYear();
      var statsYear = getStatsYear();
      var cutoff = statsYear + '-01-01';

      // 1단계: 연도 필터
      var listItems = filterYear ? items.filter(function (it) { return projectOverlapsYear(it, filterYear); }) : items;

      // 2단계: 카드 필터
      if (activeCardFilter) {
        listItems = listItems.filter(function (it) {
          return projectMatchesCardFilter(it, activeCardFilter, cutoff);
        });
      }

      // 3단계: status 필터 (URL 진입용)
      if (activeStatusFilter) {
        listItems = listItems.filter(function (it) {
          return projectMatchesStatusFilter(it, activeStatusFilter);
        });
      }

      // 통계는 항상 연도 기준 전체 (카드/status 필터 무시 — 그래야 카드 숫자가 의미를 가짐)
      updateStats(items, statsYear);
      renderTable(listItems, colVis, filterYear || STAT_YEAR, projectEditHandler);

      if (filterHint) {
        var listLabel = filterYear ? filterYear + '년' : '전체';
        var statsLabel = filterYear ? filterYear + '년' : STAT_YEAR + '년';
        filterHint.textContent = '리스트: ' + listLabel + ' / 통계: ' + statsLabel + ' 기준';
      }

      updateActiveCardUI();
      renderActiveFilterChip();
    }

    if (yearFilter) {
      yearFilter.addEventListener('change', function () {
        applyFilterAndRender(latestItems);
      });
    }

    // 카드 클릭 → 필터 토글
    document.querySelectorAll('.projects-stat-card.clickable').forEach(function (card) {
      var f = card.getAttribute('data-filter');
      function handle() {
        if (f === 'all') {
          // '전체' 카드: 모든 필터 해제
          activeCardFilter = null;
          activeStatusFilter = null;
        } else if (activeCardFilter === f) {
          // 같은 카드 재클릭: 토글 해제
          activeCardFilter = null;
        } else {
          // 다른 카드 클릭: 카드 필터 전환 (status 필터도 같이 해제)
          activeCardFilter = f;
          activeStatusFilter = null;
        }
        syncURL();
        applyFilterAndRender(latestItems);
      }
      card.addEventListener('click', handle);
      card.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handle();
        }
      });
    });

    // 과제 등록 버튼: 상세 페이지로 이동
    var addBtn = document.getElementById('project-add-btn');
    if (addBtn) {
      addBtn.addEventListener('click', function () {
        window.location.href = 'project-detail.html';
      });
    }

    // 테이블 행 "수정" 버튼: 상세 페이지로 이동 (편집 모드)
    var projectEditHandler = function (item) {
      var id = item.id || item.docId;
      if (!id) return;
      window.location.href = 'project-detail.html?id=' + encodeURIComponent(id);
    };

    if (svc && typeof svc.subscribeProjects === 'function') {
      svc.subscribeProjects(function (items) {
        applyFilterAndRender(items);
      });
    } else {
      applyFilterAndRender([]);
    }
  }


  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

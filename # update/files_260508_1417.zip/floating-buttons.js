/**
 * floating-buttons.js
 *
 * 모든 페이지에 자동으로 우측 하단 Floating Action Buttons 추가:
 *   ↑  맨 위로
 *   ↓  맨 아래로
 *   +  과제 등록 (projects.html 에서만 표시)
 *
 * 사용법: 각 페이지의 </body> 직전에 다음 한 줄만 추가:
 *   <script src="floating-buttons.js"></script>
 */
(function () {
  'use strict';

  // 중복 로드 방지
  if (window.__floatingButtonsLoaded) return;
  window.__floatingButtonsLoaded = true;

  function init() {
    // 1. CSS 동적 삽입
    var style = document.createElement('style');
    style.textContent = ''
      + '.fab-buttons {'
      +   'position: fixed;'
      +   'bottom: 1.5rem;'
      +   'right: 1.5rem;'
      +   'display: flex;'
      +   'flex-direction: column;'
      +   'gap: 0.5rem;'
      +   'z-index: 1000;'
      + '}'
      + '.fab-btn {'
      +   'width: 44px;'
      +   'height: 44px;'
      +   'border-radius: 50%;'
      +   'background: #ffffff;'
      +   'border: 1px solid #e5e7eb;'
      +   'box-shadow: 0 2px 8px rgba(0,0,0,0.08);'
      +   'cursor: pointer;'
      +   'display: flex;'
      +   'align-items: center;'
      +   'justify-content: center;'
      +   'font-size: 1.1rem;'
      +   'color: #4b5563;'
      +   'transition: all 0.2s ease;'
      +   'padding: 0;'
      +   'line-height: 1;'
      + '}'
      + '.fab-btn:hover {'
      +   'background: #f3f4f6;'
      +   'transform: translateY(-2px);'
      +   'box-shadow: 0 4px 14px rgba(0,0,0,0.15);'
      + '}'
      + '.fab-btn:active {'
      +   'transform: translateY(0);'
      + '}'
      + '.fab-btn--primary {'
      +   'background: #10b981;'
      +   'color: #ffffff;'
      +   'border-color: #10b981;'
      +   'width: 52px;'
      +   'height: 52px;'
      +   'font-size: 1.6rem;'
      +   'font-weight: 300;'
      +   'box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);'
      + '}'
      + '.fab-btn--primary:hover {'
      +   'background: #059669;'
      +   'border-color: #059669;'
      +   'box-shadow: 0 6px 16px rgba(16, 185, 129, 0.4);'
      + '}'
      + '@media (max-width: 640px) {'
      +   '.fab-buttons { bottom: 1rem; right: 1rem; }'
      + '}'
      ;
    document.head.appendChild(style);

    // 2. 페이지 감지: projects.html 인 경우에만 등록 버튼 표시
    var path = (location.pathname || '').toLowerCase();
    var isProjectsPage = /projects\.html$/.test(path) || path.endsWith('/projects');

    // 3. 버튼 컨테이너 생성
    var container = document.createElement('div');
    container.className = 'fab-buttons';
    container.setAttribute('aria-label', '페이지 내비게이션 버튼');

    var html = ''
      + '<button type="button" class="fab-btn" id="fab-scroll-top" title="맨 위로" aria-label="맨 위로">↑</button>'
      + '<button type="button" class="fab-btn" id="fab-scroll-bottom" title="맨 아래로" aria-label="맨 아래로">↓</button>';
    if (isProjectsPage) {
      html += '<button type="button" class="fab-btn fab-btn--primary" id="fab-add-project" title="새 과제 등록" aria-label="새 과제 등록">+</button>';
    }
    container.innerHTML = html;
    document.body.appendChild(container);

    // 4. 이벤트 핸들러
    var topBtn = document.getElementById('fab-scroll-top');
    if (topBtn) {
      topBtn.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }
    var bottomBtn = document.getElementById('fab-scroll-bottom');
    if (bottomBtn) {
      bottomBtn.addEventListener('click', function () {
        var h = Math.max(
          document.body.scrollHeight,
          document.documentElement.scrollHeight
        );
        window.scrollTo({ top: h, behavior: 'smooth' });
      });
    }
    if (isProjectsPage) {
      var addBtn = document.getElementById('fab-add-project');
      if (addBtn) {
        addBtn.addEventListener('click', function () {
          window.location.href = 'project-detail.html';
        });
      }
    }
  }

  // DOMContentLoaded 후 초기화
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
